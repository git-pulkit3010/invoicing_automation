"""Tests for the command line layer: the artefacts it writes and the JSON it prints.

The agent-facing contract is deliberately narrow:

* every command prints exactly **one** JSON document, so it can be piped
  straight into jq without a parser;
* the reconciliation writes a small *brief* next to the full audit trail and
  the document itself;
* the reference data is only re-read when the files behind it changed.
"""

from __future__ import annotations

import contextlib
import io
import json
import shutil
import sys
import tempfile
import unittest
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(BASE_DIR))

from invoicing.cli import main  # noqa: E402
from invoicing.db import session  # noqa: E402
from invoicing.ingest import ingest_excel, ingest_work_orders  # noqa: E402

INVOICES = BASE_DIR / "invoices"
WORK_ORDERS = BASE_DIR / "work_orders"
EXCEL = BASE_DIR / "CMPM Report_1001-103126_Final.xlsx"
SAMPLE = INVOICES / "Edge Centric_Chaitanya Motupalli_1001-103126.pdf"


def build_database(db: Path) -> None:
    """Load the reference data into a fresh database."""
    with session(db) as conn:
        ingest_excel(conn, EXCEL)
        ingest_work_orders(conn, WORK_ORDERS)


class TestIngestSkipping(unittest.TestCase):
    def test_an_unchanged_workbook_is_not_re_read(self):
        with tempfile.TemporaryDirectory() as tmp:
            with session(Path(tmp) / "t.db") as conn:
                first = ingest_excel(conn, EXCEL)
                self.assertTrue(first.reloaded)
                second = ingest_excel(conn, EXCEL)
                self.assertFalse(second.reloaded)
                self.assertEqual(second.unchanged, 1)

    def test_an_unchanged_work_order_is_not_re_read(self):
        with tempfile.TemporaryDirectory() as tmp:
            db = Path(tmp) / "t.db"
            with session(db) as conn:
                ingest_excel(conn, EXCEL)
                first = ingest_work_orders(conn, WORK_ORDERS)
                self.assertEqual(first.work_orders, 4)
                second = ingest_work_orders(conn, WORK_ORDERS)
                self.assertEqual(second.work_orders, 0)
                self.assertEqual(second.unchanged, 4)

    def test_a_removed_work_order_leaves_the_database(self):
        with tempfile.TemporaryDirectory() as tmp:
            folder = Path(tmp) / "work_orders"
            folder.mkdir()
            copy = folder / "Chaitanya Motupalli Vendor_Work_Order_CN.pdf"
            shutil.copy(
                WORK_ORDERS / "Chaitanya Motupalli Vendor_Work_Order_CN.pdf", copy
            )
            with session(Path(tmp) / "t.db") as conn:
                ingest_excel(conn, EXCEL)
                result = ingest_work_orders(conn, folder)
                self.assertEqual(result.work_orders, 1)
                copy.unlink()
                result = ingest_work_orders(conn, folder)
                self.assertEqual(
                    result.removed, ["Chaitanya Motupalli Vendor_Work_Order_CN.pdf"]
                )
                rows = conn.execute("SELECT COUNT(*) FROM work_orders").fetchone()[0]
                self.assertEqual(rows, 0)


class TestCommandLine(unittest.TestCase):
    def _run(self, argv):
        buffer = io.StringIO()
        with contextlib.redirect_stdout(buffer):
            code = main(argv)
        return code, buffer.getvalue()

    def test_reconcile_invoice_prints_one_json_document(self):
        with tempfile.TemporaryDirectory() as tmp:
            db = Path(tmp) / "t.db"
            out = Path(tmp) / "out"
            build_database(db)
            code, text = self._run([
                "--db", str(db), "reconcile-invoice", str(SAMPLE),
                "--output", str(out),
            ])
            self.assertEqual(code, 0)
            payload = json.loads(text)  # one document, not several
            self.assertEqual(payload["status"], "MATCH")
            self.assertEqual(payload["contractor_id"], "cx6008")
            self.assertEqual(payload["amount"]["difference"], "0.00")

    def test_reconcile_invoice_writes_every_artefact(self):
        with tempfile.TemporaryDirectory() as tmp:
            db = Path(tmp) / "t.db"
            out = Path(tmp) / "out"
            build_database(db)
            self._run([
                "--db", str(db), "reconcile-invoice", str(SAMPLE),
                "--output", str(out),
            ])
            stem = SAMPLE.stem
            for suffix in (".json", ".md", ".brief.json", ".source.md"):
                self.assertTrue((out / f"{stem}{suffix}").is_file(), suffix)
            source = (out / f"{stem}.source.md").read_text(encoding="utf-8")
            self.assertIn("Edge Centric", source)
            self.assertIn("15,200", source)

    def test_the_brief_is_much_smaller_than_the_audit_trail(self):
        with tempfile.TemporaryDirectory() as tmp:
            db = Path(tmp) / "t.db"
            out = Path(tmp) / "out"
            build_database(db)
            self._run([
                "--db", str(db), "reconcile-invoice", str(SAMPLE),
                "--output", str(out),
            ])
            stem = SAMPLE.stem
            brief = (out / f"{stem}.brief.json").stat().st_size
            full = (out / f"{stem}.json").stat().st_size
            self.assertLess(brief, full / 3)

    def test_reconcile_all_prints_one_json_document(self):
        with tempfile.TemporaryDirectory() as tmp:
            db = Path(tmp) / "t.db"
            out = Path(tmp) / "out"
            build_database(db)
            code, text = self._run([
                "--db", str(db), "reconcile-all", "--folder", str(INVOICES),
                "--output", str(out),
            ])
            self.assertEqual(code, 0)
            payload = json.loads(text)
            self.assertEqual(payload["processed"], 4)
            self.assertEqual(payload["by_status"]["MATCH"], 2)
            self.assertEqual(payload["by_status"]["REVIEW_REQUIRED"], 2)

    def test_source_markdown_renders_the_document(self):
        with tempfile.TemporaryDirectory() as tmp:
            out = Path(tmp) / "doc.md"
            code, _text = self._run([
                "source-markdown", str(SAMPLE), "--out", str(out),
            ])
            self.assertEqual(code, 0)
            self.assertTrue(out.is_file())
            self.assertIn("15,200", out.read_text(encoding="utf-8"))


if __name__ == "__main__":
    unittest.main()
