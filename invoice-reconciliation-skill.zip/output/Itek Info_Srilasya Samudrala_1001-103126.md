# Invoice reconciliation

**Srilasya Samudrala — October 2026**

- Invoice file: `Itek Info_Srilasya Samudrala_1001-103126.pdf`
- Invoice number: `1841`
- Vendor: ITEK INFO INC
- Contractor id: `sx4462`
- Status: **MATCH**

## Amounts

| Item | Value |
| --- | --- |
| Verified billable hours | 176 |
| Hours on the invoice | 176 |
| Contracted hourly rate | 83.00 |
| Rate on the invoice | 83.00 |
| Expected amount | 14,608.00 |
| Invoice amount | 14,608.00 |
| Difference | +0.00 |
| Currency | USD |

## Findings

- 176 hours at 83.00 equals the invoiced 14,608.00.

## Work order

| Item | Value |
| --- | --- |
| File | `Srilasya Samudrala Vendor_Work_Order_CN.pdf` |
| Reference | n/a |
| Vendor | ITEK INFO |
| Consultant | Srilasya Samudrala |
| Billing rate | USD 83 hourly |
| Rate unit | hourly |
| Effective from | 12/29/25 |
| Effective to | 12/31/26 |
| Covers the billing period | yes |

## Timesheet

| Item | Value |
| --- | --- |
| Rows used | 22 |
| Total hours | 176.0 |
| Regular hours | 176.0 |
| Overtime hours | 0.0 |
| Days recorded | 22 |
| Full-month benchmark | 176.0 |


---

Generated 2026-11-20T15:50:02+00:00 by the invoice-reconciliation engine.
