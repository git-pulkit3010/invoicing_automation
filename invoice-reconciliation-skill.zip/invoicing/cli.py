"""Command line entry points for the invoice-reconciliation pipeline.

These are the functions the agent calls.  Each one is a thin, scriptable
wrapper around the deterministic core, and each prints exactly one JSON
document on stdout so the agent can consume the result without parsing prose.

    ingest-references            refresh the SQLite records from Excel + PDFs
    extract-invoice   FILE       read a PDF into a validated extraction
    reconcile-invoice FILE       extract, reconcile, report
    reconcile-all                reconcile every invoice in the folder
    source-markdown  FILE       render a document as Markdown
    brief           FILE       the stored verdict for an invoice
    status                       show what is currently loaded
    watch                        wait for new invoices and reconcile them

The reconciliation commands print a *brief*: the verdict, the three numbers
that produced it and the reasons behind it.  The full extraction and the
document itself are written to files, so the agent only opens them when a
field actually needs checking.
"""

from __future__ import annotations

import argparse
import datetime as dt
import json
from pathlib import Path
from typing import List, Optional

from .config import (
    DB_PATH,
    EXCEL_PATH,
    INVOICES_DIR,
    OUTPUT_DIR,
    WORK_ORDERS_DIR,
    ensure_dirs,
)
from .db import session, sha256_file
from .extract import extract_invoice
from .ingest import ingest_excel, ingest_work_orders, load_roster
from .markdown import corroborate, read_facts, render_document
from .models import EXTRACTION_NEEDS_REVIEW, EXTRACTION_VERIFIED, InvoiceExtraction
from .reconcile import reconcile
from .report import render_brief, result_to_dict, write_result


def _print(payload) -> None:
    print(json.dumps(payload, indent=2, default=str))


def cmd_ingest_references(args) -> int:
    """Refresh the normalised reference records.

    Files that have not changed are not re-read, so this is cheap enough to
    run before every batch of invoices.  ``--force`` re-reads everything.
    """
    with session(args.db) as conn:
        excel = ingest_excel(
            conn, Path(args.excel) if args.excel else None, force=args.force
        )
        work_orders = ingest_work_orders(
            conn,
            Path(args.work_orders) if args.work_orders else None,
            # A new roster can change which consultant a work order belongs
            # to, so the work orders are re-read whenever the workbook was.
            force=args.force or excel.reloaded,
        )
    _print({
        "excel": {
            "source": excel.source,
            "contractors": excel.contractors,
            "timesheet_rows": excel.timesheet_rows,
            "unchanged": excel.unchanged,
            "skipped": excel.skipped,
        },
        "work_orders": {
            "source": work_orders.source,
            "work_orders": work_orders.work_orders,
            "unchanged": work_orders.unchanged,
            "removed": work_orders.removed,
            "skipped": work_orders.skipped,
        },
    })
    return 0


def _load_extraction(path: Path, roster) -> InvoiceExtraction:
    """Extract an invoice, or load a previously produced extraction."""
    if path.suffix.lower() == ".json":
        data = json.loads(path.read_text(encoding="utf-8"))
        if "extraction" in data:
            data = data["extraction"]
        return InvoiceExtraction.model_validate(data)
    extraction = extract_invoice(path, roster)
    extraction.source_sha256 = sha256_file(path)
    return extraction


def _read_twice(extraction: InvoiceExtraction, path: Path):
    """Read the document a second time -- as Markdown -- and compare.

    The PDF geometry and the Markdown rendering are two independent readings
    of the same document.  Where they disagree, one of them read the document
    wrong, and that has to be reported rather than papered over.

    Returns the Markdown text (or ``None``) and the list of findings.
    """
    if path.suffix.lower() != ".pdf":
        return None, []
    try:
        text = render_document(path)
        facts = read_facts(path, text)
    except Exception as exc:  # pragma: no cover - defensive
        return None, [f"The document could not be rendered as Markdown: {exc}"]
    findings = corroborate(extraction, facts)
    if findings:
        extraction.warnings.extend(findings)
        if extraction.extraction_status == EXTRACTION_VERIFIED:
            extraction.extraction_status = EXTRACTION_NEEDS_REVIEW
    return text, findings


def _store(conn, result, extraction) -> None:
    """Record the invoice and its result in the database."""
    conn.execute(
        "INSERT INTO reconciliation_results ("
        "invoice_file, invoice_sha256, status, contractor_id, result_json, created_at) "
        "VALUES (?, ?, ?, ?, ?, ?)",
        (
            result.invoice_file,
            extraction.source_sha256,
            result.status,
            result.contractor_id,
            json.dumps(result_to_dict(result), default=str),
            dt.datetime.now(dt.timezone.utc).isoformat(),
        ),
    )
    conn.execute(
        "INSERT OR REPLACE INTO invoices ("
        "source_file, source_sha256, page_count, vendor_name, customer_name, "
        "contractor_name, contractor_id, invoice_number, invoice_date, due_date, "
        "billing_period, period_year, period_month, currency, subtotal, tax, "
        "total, amount_due, extraction_status, extracted_json, processed_at) "
        "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        (
            extraction.source_file,
            extraction.source_sha256,
            extraction.page_count,
            extraction.vendor_name.value,
            extraction.customer_name.value,
            extraction.contractor_name.value,
            extraction.contractor_id.value,
            extraction.invoice_number.value,
            extraction.invoice_date.value,
            extraction.due_date.value,
            extraction.billing_period.value,
            extraction.period_year,
            extraction.period_month,
            extraction.currency.value,
            extraction.subtotal.value,
            extraction.tax.value,
            extraction.total.value,
            extraction.amount_due.value,
            extraction.extraction_status,
            extraction.model_dump_json(),
            dt.datetime.now(dt.timezone.utc).isoformat(),
        ),
    )


def _reconcile_one(conn, path: Path, output_dir: Path, markdown: bool = True):
    """Extract, corroborate, reconcile and write the artefacts for one invoice."""
    roster = load_roster(conn)
    extraction = _load_extraction(path, roster)
    source_text = None
    if markdown:
        source_text, _findings = _read_twice(extraction, path)
    result = reconcile(conn, extraction)
    _store(conn, result, extraction)
    paths = write_result(result, extraction, output_dir, source_text)
    return result, paths, extraction


def cmd_extract_invoice(args) -> int:
    """Read an invoice PDF into a structured, validated extraction."""
    with session(args.db) as conn:
        roster = load_roster(conn)
    path = Path(args.invoice)
    extraction = _load_extraction(path, roster)
    if args.markdown:
        _read_twice(extraction, path)
    payload = json.loads(extraction.model_dump_json())
    if args.out:
        out = Path(args.out)
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    _print(payload)
    return 0


def cmd_reconcile_invoice(args) -> int:
    """Extract, reconcile and report on a single invoice."""
    with session(args.db) as conn:
        result, paths, _extraction = _reconcile_one(
            conn, Path(args.invoice), Path(args.output), markdown=not args.no_markdown
        )
    brief = render_brief(result)
    brief["outputs"] = {key: str(value) for key, value in paths.items()}
    _print(brief)
    return 0


def cmd_reconcile_all(args) -> int:
    """Reconcile every invoice in the watched folder.

    One process, one database connection, one JSON document on stdout.
    """
    folder = Path(args.folder or INVOICES_DIR)
    output_dir = Path(args.output)
    briefs: List[dict] = []
    with session(args.db) as conn:
        for path in sorted(folder.glob("*.pdf")):
            if path.name.endswith(":Zone.Identifier"):
                continue
            result, paths, _extraction = _reconcile_one(
                conn, path, output_dir, markdown=not args.no_markdown
            )
            briefs.append({
                "invoice_file": result.invoice_file,
                "status": result.status,
                "contractor_id": result.contractor_id,
                "contractor_name": result.contractor_name,
                "period": result.period_label,
                "hours": {
                    "timesheet": result.expected_hours,
                    "invoice": result.invoice_hours,
                },
                "rate": {
                    "work_order": result.expected_rate,
                    "invoice": result.invoice_rate,
                },
                "amount": {
                    "expected": result.expected_amount,
                    "invoice": result.invoice_amount,
                    "difference": result.difference,
                },
                "reasons": result.reasons,
                "warnings": result.warnings,
                "outputs": {key: str(value) for key, value in paths.items()},
            })
    counts: dict = {}
    for entry in briefs:
        counts[entry["status"]] = counts.get(entry["status"], 0) + 1
    _print({
        "folder": str(folder),
        "processed": len(briefs),
        "by_status": counts,
        "invoices": briefs,
    })
    return 0


def cmd_source_markdown(args) -> int:
    """Render a document as Markdown.

    This is the file the agent reads when it needs to check what a document
    actually says.  It is small, it is plain text and it needs no PDF reader.
    """
    path = Path(args.invoice)
    text = render_document(path)
    if args.out:
        out = Path(args.out)
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(text, encoding="utf-8")
        _print({
            "source_file": path.name,
            "markdown": str(out),
            "characters": len(text),
        })
    else:
        print(text)
    return 0


def cmd_brief(args) -> int:
    """Print the stored verdict for an invoice, without redoing the work."""
    name = Path(args.invoice).name
    with session(args.db) as conn:
        row = conn.execute(
            "SELECT result_json FROM reconciliation_results "
            "WHERE invoice_file = ? ORDER BY created_at DESC, id DESC LIMIT 1",
            (name,),
        ).fetchone()
    if row is None:
        _print({"error": f"no stored result for {name}"})
        return 1
    _print(json.loads(row["result_json"]))
    return 0


def cmd_status(args) -> int:
    """Show what is currently loaded into the database."""
    with session(args.db) as conn:
        counts = {}
        for table in ("contractors", "timesheet_entries", "work_orders",
                      "invoices", "reconciliation_results"):
            counts[table] = conn.execute(
                f"SELECT COUNT(*) FROM {table}"
            ).fetchone()[0]
        sources = [
            dict(row) for row in conn.execute(
                "SELECT path, kind, processed_at FROM source_files ORDER BY kind, path"
            )
        ]
        by_status = {
            row["status"]: row["count"]
            for row in conn.execute(
                "SELECT status, COUNT(*) AS count FROM reconciliation_results "
                "GROUP BY status"
            )
        }
    _print({
        "database": str(args.db),
        "counts": counts,
        "reconciliation_status": by_status,
        "sources": sources,
    })
    return 0


def cmd_watch(args) -> int:
    """Watch the invoice folder and reconcile each new PDF as it lands."""
    from watchdog.events import FileSystemEventHandler
    from watchdog.observers import Observer

    folder = Path(args.folder or INVOICES_DIR)
    folder.mkdir(parents=True, exist_ok=True)
    work_orders = Path(args.work_orders) if args.work_orders else None

    class Handler(FileSystemEventHandler):
        def on_created(self, event):
            if event.is_directory:
                return
            self.handle(Path(event.src_path))

        def on_moved(self, event):
            if event.is_directory:
                return
            self.handle(Path(event.dest_path))

        def handle(self, path: Path) -> None:
            if path.suffix.lower() != ".pdf":
                return
            print(f"[watch] new file: {path.name}", flush=True)
            _settle(path)
            if work_orders and path.parent.resolve() == work_orders.resolve():
                # A new or replaced work order changes the contracted rate, so
                # the reference data is refreshed before the next invoice.
                cmd_ingest_references(argparse.Namespace(
                    db=args.db, excel=str(EXCEL_PATH), work_orders=str(work_orders),
                    force=False,
                ))
                return
            cmd_reconcile_invoice(argparse.Namespace(
                db=args.db, invoice=str(path), output=args.output,
                no_markdown=False,
            ))

    observer = Observer()
    observer.schedule(Handler(), str(folder), recursive=False)
    if work_orders and work_orders.is_dir():
        observer.schedule(Handler(), str(work_orders), recursive=False)
    observer.start()
    print(f"[watch] watching {folder} (ctrl-c to stop)", flush=True)
    try:
        while True:
            observer.join(1)
    except KeyboardInterrupt:
        observer.stop()
    observer.join()
    return 0


def _settle(path: Path) -> None:
    """Wait until the file has stopped growing (it is still being written)."""
    import time

    last = -1
    for _ in range(60):
        try:
            size = path.stat().st_size
        except OSError:
            return
        if size == last and size > 0:
            return
        last = size
        time.sleep(0.5)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="invoicing",
        description="CompNova invoice reconciliation (deterministic core).",
    )
    parser.add_argument(
        "--db", default=str(DB_PATH),
        help="path to the SQLite database (default: %(default)s)",
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    ingest = subparsers.add_parser(
        "ingest-references", help="refresh the Excel and work-order records"
    )
    ingest.add_argument("--excel", default=str(EXCEL_PATH))
    ingest.add_argument("--work-orders", default=str(WORK_ORDERS_DIR))
    ingest.add_argument(
        "--force", action="store_true",
        help="re-read every file, even the ones that have not changed",
    )
    ingest.set_defaults(func=cmd_ingest_references)

    extract_cmd = subparsers.add_parser(
        "extract-invoice", help="read an invoice PDF into structured JSON"
    )
    extract_cmd.add_argument("invoice")
    extract_cmd.add_argument("--out", help="also write the extraction to this path")
    extract_cmd.add_argument(
        "--markdown", action="store_true",
        help="also read the document as Markdown and compare the two readings",
    )
    extract_cmd.set_defaults(func=cmd_extract_invoice)

    reconcile_cmd = subparsers.add_parser(
        "reconcile-invoice", help="reconcile one invoice against the reference data"
    )
    reconcile_cmd.add_argument(
        "invoice", help="path to the invoice PDF, or to an extraction JSON file"
    )
    reconcile_cmd.add_argument("--output", default=str(OUTPUT_DIR))
    reconcile_cmd.add_argument(
        "--no-markdown", action="store_true",
        help="skip the second reading of the document (Markdown)",
    )
    reconcile_cmd.set_defaults(func=cmd_reconcile_invoice)

    all_cmd = subparsers.add_parser(
        "reconcile-all", help="reconcile every invoice in a folder"
    )
    all_cmd.add_argument("--folder", default=str(INVOICES_DIR))
    all_cmd.add_argument("--output", default=str(OUTPUT_DIR))
    all_cmd.add_argument("--no-markdown", action="store_true")
    all_cmd.set_defaults(func=cmd_reconcile_all)

    md_cmd = subparsers.add_parser(
        "source-markdown", help="render a document as Markdown"
    )
    md_cmd.add_argument("invoice")
    md_cmd.add_argument("--out", help="write the Markdown here instead of stdout")
    md_cmd.set_defaults(func=cmd_source_markdown)

    brief_cmd = subparsers.add_parser(
        "brief", help="print the stored result for an invoice"
    )
    brief_cmd.add_argument("invoice")
    brief_cmd.set_defaults(func=cmd_brief)

    status_cmd = subparsers.add_parser("status", help="show what is loaded")
    status_cmd.set_defaults(func=cmd_status)

    watch_cmd = subparsers.add_parser(
        "watch", help="reconcile invoices as they arrive in a folder"
    )
    watch_cmd.add_argument("--folder", default=str(INVOICES_DIR))
    watch_cmd.add_argument("--work-orders", default=str(WORK_ORDERS_DIR))
    watch_cmd.add_argument("--output", default=str(OUTPUT_DIR))
    watch_cmd.set_defaults(func=cmd_watch)

    return parser


def main(argv: Optional[List[str]] = None) -> int:
    ensure_dirs()
    parser = build_parser()
    args = parser.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())
