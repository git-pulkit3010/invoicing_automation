# INVOICE

- **ITEK INFO INC:** info@itekinfo.com
- **8204 Elmbrook Dr:** +1 (708) 323-8928

Ste 324  
Dallas, TX 75247

| Bill to | Ship to |
| --- | --- |
| COMPNOVA LLC | COMPNOVA LLC |
| 300 N. Coit Road | 300 N. Coit Road |
| Suite #340 | Suite #340 |
| Richardson, TX 75080 USA | Richardson, TX 75080 USA |

#### Invoice details

Invoice no.: 1841  
Terms: Net 45  
Invoice date: 11/12/2026  
Due date: 12/27/2026

| # | Product or service | Description | Qty | Rate | Amount |
| --- | --- | --- | --- | --- | --- |
|  | **Srilasya Samudrala** | Services for the month of October 2026 | 176 | $83.00 | $14,608.00 |

- **Total:** **$14,608.00**

# Ways to pay

# View and pay

token=
