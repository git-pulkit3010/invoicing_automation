#!/usr/bin/env python3
"""Run the invoice-reconciliation pipeline with its paths already pinned.

Every agent that installs this skill ends up with the same problem: the
pipeline resolves its data folders relative to the project folder, but the
agent's working directory is wherever the user happened to be.  This wrapper
removes that problem.  It knows three things -- where the pipeline code is,
where the data lives and which interpreter has the dependencies -- and it
sets all of them before running the real command.

    python scripts/run_pipeline.py reconcile "invoices/Some Vendor.pdf"
    python scripts/run_pipeline.py reconcile-all
    python scripts/run_pipeline.py ingest --force
    python scripts/run_pipeline.py status

The paths come from ``install.json``, which the installer writes next to
this file.  When that file is missing the wrapper falls back to "unpacked
repository" mode: the project folder is the parent of ``scripts/`` and the
interpreter is the virtual environment in that folder (or the current
interpreter).

The wrapper itself uses only the standard library, so it starts under any
Python 3.8+; it then re-executes the real work under the virtual environment
that holds the dependencies.
"""

from __future__ import annotations

import json
import os
import sys
from pathlib import Path

SKILL_DIR = Path(__file__).resolve().parent.parent
INSTALL_FILE = SKILL_DIR / "install.json"

#: Command name -> the ``invoicing.cli`` subcommand it maps to.
COMMAND_MAP = {
    "reconcile": "reconcile-invoice",
    "reconcile-all": "reconcile-all",
    "ingest": "ingest-references",
    "extract": "extract-invoice",
    "source-markdown": "source-markdown",
    "brief": "brief",
    "status": "status",
    "watch": "watch",
}


def _load_install() -> dict:
    if not INSTALL_FILE.is_file():
        return {}
    try:
        return json.loads(INSTALL_FILE.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def _resolve_paths() -> tuple:
    """Return ``(project_root, skill_dir, interpreter)``."""
    install = _load_install()
    # Without an install record this is the unpacked project folder, which is
    # the folder that holds SKILL.md, scripts/ and the data.
    data_root = os.environ.get("INVOICING_PROJECT_ROOT") or install.get("project_root")
    project_root = Path(data_root).expanduser().resolve() if data_root else SKILL_DIR
    code_root = Path(install.get("code_root") or ".").expanduser()
    skill_dir = (SKILL_DIR / code_root).resolve()
    interpreter = install.get("python")
    if not interpreter:
        for candidate in (
            project_root / ".venv" / "bin" / "python",
            project_root / ".venv" / "Scripts" / "python.exe",
        ):
            if candidate.is_file():
                interpreter = str(candidate)
                break
    return project_root, skill_dir, interpreter


def _venv_env(project_root: Path, skill_dir: Path) -> dict:
    """Point every data location at the project folder."""
    env = dict(os.environ)
    env.update({
        "INVOICING_PROJECT_ROOT": str(project_root),
        "INVOICING_DATA_DIR": str(project_root / "data"),
        "INVOICING_DB": str(project_root / "data" / "invoicing.db"),
        "INVOICING_CACHE_DIR": str(project_root / "data" / "cache"),
        "INVOICING_OUTPUT_DIR": str(project_root / "output"),
        "INVOICES_DIR": str(project_root / "invoices"),
        "WORK_ORDERS_DIR": str(project_root / "work_orders"),
    })
    workbooks = sorted(project_root.glob("*.xlsx"))
    if workbooks and not env.get("MASTER_EXCEL"):
        env["MASTER_EXCEL"] = str(workbooks[0])
    # The bundled package must win over anything installed elsewhere.
    python_path = [str(skill_dir), str(project_root)]
    if env.get("PYTHONPATH"):
        python_path.append(env["PYTHONPATH"])
    env["PYTHONPATH"] = os.pathsep.join(python_path)
    return env


def _fail(message: str) -> int:
    print(f"run_pipeline: {message}", file=sys.stderr)
    return 2


def main(argv=None) -> int:
    argv = list(sys.argv[1:] if argv is None else argv)
    if not argv or argv[0] in ("-h", "--help", "help"):
        print(__doc__.strip())
        print("\nCommands: " + ", ".join(sorted(COMMAND_MAP)))
        return 0

    project_root, skill_dir, interpreter = _resolve_paths()
    if not project_root.is_dir():
        return _fail(
            f"data root {project_root} does not exist; set INVOICING_PROJECT_ROOT "
            "or reinstall with --project-root"
        )
    if not (skill_dir / "invoicing" / "cli.py").is_file():
        return _fail(f"the pipeline package is not in {skill_dir}")

    command = argv[0]
    if command == "python":          # escape hatch: raw invoicing.cli arguments
        cli_args = argv[1:]
    elif command in COMMAND_MAP:
        cli_args = [COMMAND_MAP[command], *argv[1:]]
    else:
        return _fail(
            f"unknown command {command!r}; try one of: "
            + ", ".join(sorted(COMMAND_MAP))
        )

    if command == "reconcile-all" and not (project_root / "invoices").is_dir():
        return _fail(f"invoice folder is missing from data root {project_root}")
    if command in {"status", "reconcile", "reconcile-all", "watch", "brief"}:
        database = project_root / "data" / "invoicing.db"
        if not database.is_file():
            return _fail(f"reference database is missing: {database}; run ingest")
    if command == "ingest":
        workbook = os.environ.get("MASTER_EXCEL")
        if not (workbook and Path(workbook).is_file()) and not list(project_root.glob("*.xlsx")):
            return _fail(f"no master workbook found in data root {project_root}")

    if interpreter and Path(interpreter).is_file():
        python = interpreter
    else:
        python = sys.executable
        if not interpreter:
            print(
                "run_pipeline: no virtual environment found; using the current "
                "interpreter. Install the dependencies with "
                "'pip install -r requirements.txt'.",
                file=sys.stderr,
            )

    env = _venv_env(project_root, skill_dir)
    os.chdir(project_root)
    os.execve(python, [python, "-m", "invoicing.cli", *cli_args], env)


if __name__ == "__main__":
    raise SystemExit(main())
