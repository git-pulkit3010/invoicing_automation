#!/usr/bin/env bash
#
# Convenience wrapper around scripts/install_skill.py.
#
#   ./scripts/install_skill.sh                # install for Codex
#   ./scripts/install_skill.sh --agent claude-code
#   ./scripts/install_skill.sh --agent all
#   ./scripts/install_skill.sh --verify
#
# Everything the script does -- the virtual environment, the libraries, the
# companion module, the copy into the agent's skills directory and the
# verification -- is in the Python installer, which works the same on
# macOS, Linux and Windows.
set -euo pipefail

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PYTHON="${PYTHON:-python3}"

case "${1:-}" in
    --verify)
        shift
        exec "$PYTHON" "$REPO_ROOT/scripts/install_skill.py" verify "$@"
        ;;
    --uninstall)
        shift
        exec "$PYTHON" "$REPO_ROOT/scripts/install_skill.py" uninstall "$@"
        ;;
    --agents)
        shift
        exec "$PYTHON" "$REPO_ROOT/scripts/install_skill.py" agents "$@"
        ;;
    *)
        if [ "$#" -eq 0 ]; then
            set -- --agent codex
        fi
        exec "$PYTHON" "$REPO_ROOT/scripts/install_skill.py" install "$@"
        ;;
esac
