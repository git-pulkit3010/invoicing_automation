"""Tests for the Markdown rendering and the second reading it gives.

The point of these tests is that the Markdown rendering is *independent* of
the PDF extraction: it comes from a different layout analysis.  When the two
readings agree the numbers are solid; when they do not, the engine has to say
so instead of quietly picking one.
"""

from __future__ import annotations

import sys
import unittest
from decimal import Decimal
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(BASE_DIR))

from invoicing.extract import extract_invoice  # noqa: E402
from invoicing.markdown import (  # noqa: E402
    corroborate,
    parse_tables,
    parse_totals,
    read_facts,
    render_document,
)
from invoicing.textutil import (  # noqa: E402
    markdown_numbers,
    same_number,
    strip_markdown,
)

INVOICES = BASE_DIR / "invoices"

SAMPLE = INVOICES / "Edge Centric_Chaitanya Motupalli_1001-103126.pdf"


class TestMarkdownHelpers(unittest.TestCase):
    def test_strip_markdown_removes_decoration(self):
        self.assertEqual(strip_markdown("**Total:**"), "Total:")
        self.assertEqual(strip_markdown("`amount due`"), "amount due")
        self.assertEqual(strip_markdown(""), "")

    def test_markdown_numbers_reads_grouped_digits(self):
        self.assertIn(Decimal("15200.00"), markdown_numbers("$15,200.00"))
        self.assertIn(Decimal("98.00"), markdown_numbers("$ 98.00"))

    def test_same_number_uses_the_money_tolerance(self):
        self.assertTrue(same_number(Decimal("100"), Decimal("100.00")))
        self.assertFalse(same_number(Decimal("100"), Decimal("100.01")))


class TestRendering(unittest.TestCase):
    def test_render_produces_markdown(self):
        text = render_document(SAMPLE)
        self.assertIn("Edge Centric", text)
        self.assertIn("15,200", text)

    def test_totals_are_read_back(self):
        totals = parse_totals(render_document(SAMPLE))
        self.assertTrue(same_number(totals.get("subtotal"), Decimal("15200.00")))
        self.assertTrue(same_number(totals.get("total"), Decimal("15200.00")))

    def test_table_rows_are_read_back(self):
        lines = parse_tables(render_document(SAMPLE))
        self.assertEqual(len(lines), 1)
        self.assertTrue(same_number(lines[0].quantity, Decimal("152")))
        self.assertTrue(same_number(lines[0].unit_rate, Decimal("100.00")))
        self.assertTrue(same_number(lines[0].amount, Decimal("15200.00")))


class TestCorroboration(unittest.TestCase):
    def test_every_sample_invoice_agrees_with_its_markdown(self):
        for path in sorted(INVOICES.glob("*.pdf")):
            if path.name.endswith(":Zone.Identifier"):
                continue
            with self.subTest(invoice=path.name):
                extraction = extract_invoice(path)
                facts = read_facts(path)
                self.assertTrue(facts.available)
                self.assertEqual(corroborate(extraction, facts), [])

    def test_every_sample_invoice_has_a_readable_table(self):
        """The second reading has to work on every layout, not just the easy ones."""
        for path in sorted(INVOICES.glob("*.pdf")):
            if path.name.endswith(":Zone.Identifier"):
                continue
            with self.subTest(invoice=path.name):
                facts = read_facts(path)
                self.assertTrue(facts.structured, path.name)
                self.assertTrue(facts.lines, path.name)

    def test_a_row_that_starts_with_an_empty_cell_keeps_its_columns(self):
        """A leading empty cell must not shift the whole row to the left."""
        rows = [
            "| # | Services Summary | Quantity | Rate | Amount |",
            "| --- | --- | --- | --- | --- |",
            "|  | Harish Giriraju | 160 | 73.00 | 11680.00 |",
        ]
        newline = chr(10)
        text = newline.join(rows) + newline
        lines = parse_tables(text)
        self.assertEqual(len(lines), 1)
        self.assertTrue(same_number(lines[0].quantity, Decimal("160")))
        self.assertTrue(same_number(lines[0].unit_rate, Decimal("73.00")))
        self.assertTrue(same_number(lines[0].amount, Decimal("11680.00")))

    def test_a_labelled_total_wrapped_in_emphasis_is_read(self):
        totals = parse_totals("- **Subtotal:** **11680.00 USD**")
        self.assertTrue(same_number(totals.get("subtotal"), Decimal("11680.00")))
        totals = parse_totals("- **Total:** **$14,608.00**")
        self.assertTrue(same_number(totals.get("total"), Decimal("14608.00")))
        totals = parse_totals("## Amount due $15,200.00")
        self.assertTrue(same_number(totals.get("amountdue"), Decimal("15200.00")))

    def test_a_number_the_markdown_does_not_show_is_reported(self):
        extraction = extract_invoice(SAMPLE)
        facts = read_facts(SAMPLE)
        facts.numbers = [n for n in facts.numbers if n != Decimal("15200.00")]
        findings = corroborate(extraction, facts)
        self.assertTrue(findings)
        self.assertIn("does not show", findings[0])

    def test_a_different_quantity_is_reported(self):
        extraction = extract_invoice(SAMPLE)
        facts = read_facts(SAMPLE)
        facts.lines[0].quantity = Decimal("151")
        findings = corroborate(extraction, facts)
        self.assertTrue(findings)
        self.assertIn("quantity", findings[0])


if __name__ == "__main__":
    unittest.main()
