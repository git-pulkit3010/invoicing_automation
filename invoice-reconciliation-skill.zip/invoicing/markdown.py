"""Markdown rendering of source documents, and the second reading it gives.

The extractor reads the *geometry* of a PDF: word boxes, rows and cells.
This module renders the same document to Markdown -- plain text with the
tables intact -- and reads the numbers back out of it.

That is worth doing for two reasons.

**Speed.**  The agent cannot read a PDF.  It can read Markdown, and for these
invoices the whole document is under a kilobyte -- against the ~9 kB of JSON
the extraction produces.  The pipeline writes the rendering next to the
report, so checking a field costs one file read instead of a second command.

**Accuracy.**  The Markdown comes from a *different* layout analysis (block
and table reconstruction) than the cell geometry the extractor uses.  Two
independent readings that agree are stronger evidence than either one alone;
two that disagree mean a field has to be reviewed by a human.  The engine
never quietly prefers one reading over the other.
"""

from __future__ import annotations

import importlib.util
import re
import sys
import tempfile
from decimal import Decimal
from pathlib import Path
from types import ModuleType
from typing import Dict, List, Optional, Sequence

from .config import CACHE_DIR
from .models import DocumentFacts, InvoiceExtraction, MarkdownLine
from .textutil import (
    markdown_numbers,
    parse_amount,
    parse_number,
    same_number,
    strip_markdown,
)

#: Where the PDF -> Markdown converter may live, in order of preference.
CONVERTER_CANDIDATES = (
    Path(__file__).resolve().parent.parent / "pdf_md.py",
    Path(__file__).resolve().parent.parent.parent / "pdf-to-markdown" / "pdf_md.py",
    Path(__file__).resolve().parent.parent.parent
    / "invoicing_automation" / "pdf_to_markdown.py",
)

#: Column vocabulary for the Markdown tables (kept in step with extract.py).
QTY_WORDS = ("quantity", "qty", "hours", "hrs", "billable hours")
RATE_WORDS = ("rate", "price", "unit price", "unit rate", "hourly rate")
AMOUNT_WORDS = ("amount", "line total", "extended amount", "net amount", "total")
DESC_WORDS = ("description", "product or service", "item", "items", "activity", "detail")

#: Words that end the billable rows of a table.
TOTALS_WORDS = ("subtotal", "sub total", "tax", "total", "amount due", "balance due")

#: A labelled total, e.g. ``**Subtotal:** **$15,200.00**``.  The Markdown
#: decoration between the label and the number is allowed for, because the
#: renderer wraps both the label and the value in its own emphasis marks.
_LABELLED_TOTAL_RE = re.compile(
    r"(?i)\b(sub\s*total|amount\s+due|balance\s+due|grand\s+total|net\s+total"
    r"|invoice\s+total|total|tax)\b[\s:*_\-]*\$?[\s:*_]*"
    r"([\d][\d,]*(?:\.\d+)?)"
)
_TABLE_ROW_RE = re.compile(r"^\s*\|(.*)\|\s*$")
_SEPARATOR_RE = re.compile(r"^[\s|:-]+$")

_converter_module: Optional[ModuleType] = None
_converter_loaded = False


# --------------------------------------------------------------------------- #
# Rendering
# --------------------------------------------------------------------------- #


def find_converter() -> Optional[Path]:
    """Locate the PDF -> Markdown converter."""
    for candidate in CONVERTER_CANDIDATES:
        if candidate.is_file():
            return candidate
    return None


def load_converter() -> Optional[ModuleType]:
    """Import the converter once and keep it around.

    Returns ``None`` when the converter is not on the machine; the pipeline
    then falls back to a plain-text rendering so that nothing breaks.
    """
    global _converter_module, _converter_loaded
    if _converter_loaded:
        return _converter_module
    _converter_loaded = True
    path = find_converter()
    if path is None:
        return None
    spec = importlib.util.spec_from_file_location("invoicing_pdf_md", path)
    if spec is None or spec.loader is None:
        return None
    module = importlib.util.module_from_spec(spec)
    # The converter uses ``@dataclass``, which looks the module up in
    # ``sys.modules`` while the class is being created -- so register it
    # before executing it.
    sys.modules[spec.name] = module
    try:
        spec.loader.exec_module(module)
    except Exception:  # pragma: no cover - a broken converter must not break a run
        sys.modules.pop(spec.name, None)
        return None
    _converter_module = module
    return _converter_module


def _plain_text(pdf_path: Path) -> str:
    """Fallback rendering: the raw text layer of the document."""
    import pymupdf

    doc = pymupdf.open(pdf_path)
    try:
        pages = [page.get_text("text") for page in doc]
    finally:
        doc.close()
    return "\n\n".join(pages)


def _cache_path(pdf_path: Path) -> Path:
    from .db import sha256_file

    digest = sha256_file(pdf_path)[:12]
    return CACHE_DIR / f"{pdf_path.stem}-{digest}.md"


def render_document(pdf_path: Path, use_cache: bool = True) -> str:
    """Render a PDF as Markdown.

    The rendering is cached next to the database, keyed by the content of the
    PDF, so a second run over the same folder does not re-parse anything.
    """
    pdf_path = Path(pdf_path)
    if use_cache:
        cached = _cache_path(pdf_path)
        if cached.is_file() and cached.stat().st_mtime >= pdf_path.stat().st_mtime:
            return cached.read_text(encoding="utf-8")

    module = load_converter()
    text = ""
    converted = False
    if module is not None and hasattr(module, "convert"):
        CACHE_DIR.mkdir(parents=True, exist_ok=True)
        with tempfile.TemporaryDirectory() as tmp:
            target = Path(tmp) / f"{pdf_path.stem}.md"
            try:
                module.convert(pdf_path, target)
                text = target.read_text(encoding="utf-8")
                converted = bool(text.strip())
            except Exception:
                text = ""
    if not text.strip():
        text = _plain_text(pdf_path)

    # Only a real Markdown rendering is cached: the plain-text fallback is
    # a degraded stand-in and must not be served to the next run.
    if use_cache and converted:
        cached = _cache_path(pdf_path)
        cached.parent.mkdir(parents=True, exist_ok=True)
        cached.write_text(text, encoding="utf-8")
    return text


def write_source_markdown(pdf_path: Path, target: Path) -> Path:
    """Write the Markdown rendering of ``pdf_path`` to ``target``."""
    target = Path(target)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(render_document(pdf_path), encoding="utf-8")
    return target


# --------------------------------------------------------------------------- #
# Reading the rendering
# --------------------------------------------------------------------------- #


def _split_row(line: str) -> List[str]:
    """Split one Markdown table row into its cells.

    The outer pipes are removed one at a time, so a row that starts (or ends)
    with an *empty* cell keeps that cell.  Stripping every pipe would shift
    every column to the left and silently misalign the row.
    """
    text = line.strip()
    if text.startswith("|"):
        text = text[1:]
    if text.endswith("|"):
        text = text[:-1]
    return [cell.strip() for cell in text.split("|")]


def _table_blocks(text: str) -> List[List[List[str]]]:
    """Split the Markdown into tables, each one a list of rows of cells."""
    tables: List[List[List[str]]] = []
    current: List[List[str]] = []
    for raw in text.splitlines():
        match = _TABLE_ROW_RE.match(raw)
        if not match:
            if current:
                tables.append(current)
                current = []
            continue
        if _SEPARATOR_RE.match(raw):
            continue
        current.append(_split_row(raw))
    if current:
        tables.append(current)
    return tables


def _matches_role(text: str, words: Sequence[str]) -> bool:
    label = strip_markdown(text).lower().strip()
    if not label:
        return False
    if label in words:
        return True
    return any(word in label for word in words if len(word) > 4)


def _classify_header(cells: Sequence[str]) -> Dict[str, Optional[int]]:
    """Map the qty / rate / amount / description roles onto column indexes."""
    roles: Dict[str, Optional[int]] = {
        "qty": None, "rate": None, "amount": None, "description": None,
    }
    for index, cell in enumerate(cells):
        if roles["qty"] is None and _matches_role(cell, QTY_WORDS):
            roles["qty"] = index
        elif roles["rate"] is None and _matches_role(cell, RATE_WORDS):
            roles["rate"] = index
        elif roles["amount"] is None and _matches_role(cell, AMOUNT_WORDS):
            roles["amount"] = index
        elif roles["description"] is None and _matches_role(cell, DESC_WORDS):
            roles["description"] = index
    return roles


def _is_totals_row(cells: Sequence[str]) -> bool:
    joined = strip_markdown(" ".join(cells)).lower()
    return any(word in joined for word in TOTALS_WORDS)


def parse_tables(text: str) -> List[MarkdownLine]:
    """Read the billable rows out of the Markdown tables.

    A table is only read when its header names a quantity, a rate *and* an
    amount -- the same rule the PDF extractor uses, so the two readings stay
    comparable.  Rows after the header are billable rows until a totals row
    ends the table.
    """
    lines: List[MarkdownLine] = []
    for table in _table_blocks(text):
        roles: Dict[str, Optional[int]] = {}
        header_index = -1
        for row_index, row in enumerate(table):
            candidate = _classify_header(row)
            if (candidate["qty"] is not None and candidate["rate"] is not None
                    and candidate["amount"] is not None):
                roles = candidate
                header_index = row_index
                break
        if header_index < 0:
            continue

        widest = max(index for index in roles.values() if index is not None)
        for row in table[header_index + 1:]:
            if _is_totals_row(row):
                break
            if len(row) <= widest:
                continue
            quantity = rate = amount = None
            if roles["qty"] is not None:
                quantity = parse_number(strip_markdown(row[roles["qty"]]))
            if roles["rate"] is not None:
                rate = parse_amount(strip_markdown(row[roles["rate"]]))
            if roles["amount"] is not None:
                amount = parse_amount(strip_markdown(row[roles["amount"]]))
            if quantity is None and rate is None and amount is None:
                continue
            description = None
            if roles["description"] is not None:
                description = strip_markdown(row[roles["description"]]) or None
            lines.append(MarkdownLine(
                description=description,
                quantity=quantity,
                unit_rate=rate,
                amount=amount,
            ))
    return lines


def parse_totals(text: str) -> Dict[str, Decimal]:
    """Read the labelled totals (``Subtotal``, ``Total``, ``Tax`` ...)."""
    totals: Dict[str, Decimal] = {}
    for raw in text.splitlines():
        for match in _LABELLED_TOTAL_RE.finditer(raw):
            label = re.sub(r"\s+", " ", match.group(1).strip().lower())
            value = parse_amount(match.group(2))
            if value is None:
                continue
            key = re.sub(r"\s+", "", label)
            totals.setdefault(key, value)
    return totals


def read_facts(pdf_path: Path, text: Optional[str] = None) -> DocumentFacts:
    """Read the facts of a document out of its Markdown rendering."""
    pdf_path = Path(pdf_path)
    if text is None:
        text = render_document(pdf_path)
    facts = DocumentFacts(source_file=pdf_path.name, available=True)
    facts.numbers = markdown_numbers(text)
    facts.totals = parse_totals(text)
    facts.lines = parse_tables(text)
    facts.structured = bool(facts.lines)
    return facts


# --------------------------------------------------------------------------- #
# Corroboration
# --------------------------------------------------------------------------- #


def _find_matching_line(amount: Decimal, lines: Sequence[MarkdownLine]) -> Optional[MarkdownLine]:
    for line in lines:
        if line.amount is not None and same_number(line.amount, amount):
            return line
    return None


def corroborate(extraction: InvoiceExtraction, facts: DocumentFacts) -> List[str]:
    """Compare the extraction with the second reading of the document.

    Returns a list of findings.  A finding means *one of the two readings is
    wrong*, never that the invoice is wrong -- so they are reported as
    warnings and never silently change a verdict.
    """
    findings: List[str] = []
    if not facts.available:
        return findings

    for item in extraction.line_items:
        if item.amount is None:
            continue
        if not facts.has_number(item.amount):
            findings.append(
                f"The Markdown rendering of the document does not show the line "
                f"amount {item.amount} that was read from the PDF."
            )
            continue
        if not facts.structured:
            continue
        match = _find_matching_line(item.amount, facts.lines)
        if match is None:
            continue
        if (item.quantity is not None and match.quantity is not None
                and not same_number(item.quantity, match.quantity)):
            findings.append(
                f"The quantity for the line of {item.amount} was read as "
                f"{item.quantity}, but the Markdown rendering of the table "
                f"shows {match.quantity}."
            )
        if (item.unit_rate is not None and match.unit_rate is not None
                and not same_number(item.unit_rate, match.unit_rate)):
            findings.append(
                f"The rate for the line of {item.amount} was read as "
                f"{item.unit_rate}, but the Markdown rendering of the table "
                f"shows {match.unit_rate}."
            )

    for key, field in (
        ("subtotal", extraction.subtotal),
        ("total", extraction.total),
        ("amountdue", extraction.amount_due),
        ("tax", extraction.tax),
    ):
        if not field.present():
            continue
        value = parse_amount(field.value)
        if value is None:
            continue
        other = facts.totals.get(key)
        if other is None:
            continue
        if not same_number(value, other):
            findings.append(
                f"The {key} was read as {value}, but the Markdown rendering of "
                f"the document shows {other}."
            )
    return findings
