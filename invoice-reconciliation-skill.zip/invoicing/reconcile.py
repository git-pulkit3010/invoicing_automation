"""The reconciliation engine.

This module owns every number in the decision.  It compares what the vendor
billed against what the master timesheet and the work order say should have
been billed, and it explains the outcome in words.

The rules it enforces come straight from the architecture:

* Hours come from the timesheet, never from the invoice.
* The rate comes from the work order that is *effective* for the billing
  period, never from the invoice.
* ``hours x rate`` is compared against the invoice **subtotal**, not its
  final payable total, so taxes and adjustments do not muddy the check.
* Anything uncertain is ``REVIEW_REQUIRED``.  A missing rate, an ambiguous
  contractor or an unreadable document never produces a confident match or a
  confident mismatch.
"""

from __future__ import annotations

import calendar
import datetime as dt
import sqlite3
from decimal import Decimal
from typing import List, Optional, Tuple

from .config import HOURS_EPSILON, MONEY_EPSILON
from .hours_source import HoursSourceUnavailable, report_from_rows
from .models import (
    EXTRACTION_FAILED,
    STATUS_MATCH,
    STATUS_MISMATCH,
    STATUS_REVIEW,
    InvoiceExtraction,
    ReconciliationResult,
)
from .textutil import norm_name, parse_amount, parse_date, parse_number

TWO_PLACES = Decimal("0.01")


def _money(value: Optional[Decimal]) -> Optional[Decimal]:
    return None if value is None else value.quantize(TWO_PLACES)


def _period_bounds(year: int, month: int) -> Tuple[dt.date, dt.date]:
    last = calendar.monthrange(year, month)[1]
    return dt.date(year, month, 1), dt.date(year, month, last)


def _money_str(value: Optional[Decimal]) -> str:
    if value is None:
        return "n/a"
    return f"{value:,.2f}"


def _hours_str(value: Optional[Decimal]) -> str:
    if value is None:
        return "n/a"
    if abs(value - round(value)) < Decimal("0.001"):
        return str(int(round(value)))
    return f"{value.normalize():f}"


def _work_orders_for(
    conn: sqlite3.Connection,
    contractor_id: Optional[str],
    consultant_name: Optional[str],
    vendor_name: Optional[str],
) -> List[sqlite3.Row]:
    """Find the work orders that might apply to this invoice."""
    if contractor_id:
        rows = list(conn.execute(
            "SELECT * FROM work_orders WHERE consultant_id = ? "
            "ORDER BY COALESCE(start_date, '')",
            (contractor_id,),
        ))
        if rows:
            return rows
    if consultant_name:
        wanted = norm_name(consultant_name)
        rows = [
            row for row in conn.execute("SELECT * FROM work_orders")
            if wanted and wanted in norm_name(row["consultant_name"] or "")
        ]
        if rows:
            return rows
    if vendor_name:
        wanted = norm_name(vendor_name)
        rows = [
            row for row in conn.execute("SELECT * FROM work_orders")
            if wanted and wanted in norm_name(row["vendor_name"] or "")
        ]
        if rows:
            return rows
    return []


def _pick_effective_work_order(
    rows: List[sqlite3.Row],
    period_start: dt.date,
    period_end: dt.date,
) -> Tuple[Optional[sqlite3.Row], List[str]]:
    """Choose the work order whose effective dates cover the billing period.

    Returns the chosen row (or ``None``) and the reasons why the choice was
    not straightforward.
    """
    notes: List[str] = []
    if not rows:
        return None, notes

    dated = []
    for row in rows:
        start = parse_date(row["start_date"])
        end = parse_date(row["end_date"])
        if start or end:
            dated.append((row, start, end))

    effective = []
    for row, start, end in dated:
        starts_ok = start is None or start <= period_end
        ends_ok = end is None or end >= period_start
        if starts_ok and ends_ok:
            effective.append((row, start, end))

    if len(effective) == 1:
        return effective[0][0], notes
    if len(effective) > 1:
        notes.append(
            "More than one work order covers the billing period "
            f"({', '.join(sorted(str(r['source_file']) for r, _, _ in effective))}); "
            "the one that was still open at the end of the period was used."
        )
        effective.sort(key=lambda item: (item[1] or dt.date.min))
        return effective[-1][0], notes

    # Nothing covers the period: fall back to the most recent work order so
    # the report can still say what rate was on file.
    dated.sort(key=lambda item: (item[2] or item[1] or dt.date.min))
    latest = dated[-1]
    row, start, end = latest
    if end and end < period_start:
        notes.append(
            f"The most recent work order for this consultant ({row['source_file']}) "
            f"expired on {end.isoformat()}, before the billing period started."
        )
    elif start and start > period_end:
        notes.append(
            f"The most recent work order for this consultant ({row['source_file']}) "
            f"only starts on {start.isoformat()}, after the billing period ended."
        )
    return row, notes


def reconcile(
    conn: sqlite3.Connection,
    extraction: InvoiceExtraction,
) -> ReconciliationResult:
    """Reconcile one invoice against the reference data."""
    result = ReconciliationResult(invoice_file=extraction.source_file)
    reasons = result.reasons
    warnings = result.warnings

    invoice_number = extraction.invoice_number.value
    vendor_name = extraction.vendor_name.value
    result.invoice_number = invoice_number
    result.vendor_name = vendor_name
    result.currency = extraction.currency.value or "USD"

    # --- what the invoice claims -----------------------------------------
    line_amount = extraction.billed_amount()
    line_hours = extraction.billed_quantity()
    line_rates = [i.unit_rate for i in extraction.line_items if i.unit_rate is not None]
    invoice_rate = line_rates[0] if line_rates else None
    if len(set(line_rates)) > 1:
        warnings.append(
            "The invoice bills more than one rate; the first line item was used."
        )

    subtotal = parse_amount(extraction.subtotal.value)
    total = parse_amount(extraction.total.value)
    amount_due = parse_amount(extraction.amount_due.value)
    invoice_amount = subtotal or line_amount or total
    if subtotal is not None and line_amount is not None and abs(subtotal - line_amount) > MONEY_EPSILON:
        warnings.append(
            f"The invoice subtotal ({_money_str(subtotal)}) differs from the sum of "
            f"its line items ({_money_str(line_amount)})."
        )
    if invoice_amount is None:
        warnings.append("No invoice amount could be read from the document.")
    result.invoice_amount = _money(invoice_amount)
    result.invoice_hours = _money(line_hours)
    result.invoice_rate = _money(invoice_rate)

    # --- who is being billed ---------------------------------------------
    contractor_id = extraction.contractor_id.value
    contractor_name = extraction.contractor_name.value
    if contractor_id:
        row = conn.execute(
            "SELECT * FROM contractors WHERE contractor_id = ?", (contractor_id,)
        ).fetchone()
        if row is None:
            warnings.append(
                f"Contractor id '{contractor_id}' is not in the master timesheet."
            )
            contractor_id = None
        else:
            contractor_name = row["full_name"]
            result.contractor_id = contractor_id
            result.contractor_name = contractor_name
    if not contractor_id:
        reasons.append(
            "The consultant could not be matched to a record in the master "
            "timesheet, so the billed hours cannot be verified."
        )

    # --- which period -----------------------------------------------------
    year, month = extraction.period_year, extraction.period_month
    if year and month:
        result.period_year, result.period_month = year, month
        result.period_label = f"{calendar.month_name[month]} {year}"
    else:
        reasons.append(
            "The billing period could not be determined from the invoice."
        )

    # --- hours from the timesheet -----------------------------------------
    expected_hours: Optional[Decimal] = None
    audit: dict = {}
    if contractor_id and year and month:
        rows = list(conn.execute(
            "SELECT t.*, c.first_name AS c_first, c.last_name AS c_last, "
            "c.vendor_name AS c_vendor "
            "FROM timesheet_entries t "
            "LEFT JOIN contractors c ON c.contractor_id = t.contractor_id "
            "WHERE t.contractor_id = ? AND t.period_year = ? AND t.period_month = ? "
            "ORDER BY t.work_date",
            (contractor_id, year, month),
        ))
        if not rows:
            reasons.append(
                f"The master timesheet has no entries for {contractor_name} in "
                f"{result.period_label or 'the billing period'}."
            )
        else:
            expected_hours = sum(
                (Decimal(str(row["total_hours"] or 0)) for row in rows), Decimal("0")
            )
            # The companion hours calculator replays the review dashboard's own
            # checks over these rows.  It is an audit, not the verdict: the
            # hours above come from the timesheet table.  If the companion is
            # not installed, say so and keep going.
            try:
                audit["timesheet"] = _timesheet_audit(
                    conn, rows, contractor_id, year, month
                )
            except HoursSourceUnavailable as exc:
                warnings.append(
                    "The timesheet audit was skipped: the companion "
                    f"'hours_calculator' module is not installed ({exc}). The "
                    "verdict still uses the master timesheet rows; install the "
                    "companion to get duplicate-day and missing-day warnings."
                )

    result.expected_hours = _money(expected_hours)
    if expected_hours is not None and line_hours is not None:
        result.hours_difference = _money(line_hours - expected_hours)

    # --- rate from the work order ----------------------------------------
    expected_rate: Optional[Decimal] = None
    period_start = period_end = None
    if year and month:
        period_start, period_end = _period_bounds(year, month)
        rows = _work_orders_for(conn, contractor_id, contractor_name, vendor_name)
        work_order, notes = _pick_effective_work_order(rows, period_start, period_end)
        warnings.extend(notes)
        if work_order is None:
            reasons.append(
                "No work order on file for this consultant, so there is no "
                "contracted rate to check the invoice against."
            )
        else:
            expected_rate = parse_number(work_order["billing_rate"])
            audit["work_order"] = {
                "source_file": work_order["source_file"],
                "work_order_ref": work_order["work_order_ref"],
                "vendor_name": work_order["vendor_name"],
                "consultant_name": work_order["consultant_name"],
                "billing_rate": work_order["billing_rate"],
                "rate_unit": work_order["rate_unit"],
                "start_date": work_order["start_date"],
                "end_date": work_order["end_date"],
                "net_days": work_order["net_days"],
                "covers_period": bool(
                    (not work_order["start_date"] or parse_date(work_order["start_date"]) <= period_end)
                    and (not work_order["end_date"] or parse_date(work_order["end_date"]) >= period_start)
                ),
            }
            if expected_rate is None:
                reasons.append(
                    "The work order does not state a rate that could be read."
                )
            elif not audit["work_order"]["covers_period"]:
                reasons.append(
                    "No work order is in force for the billing period, so the "
                    "billed rate cannot be confirmed against a contract."
                )

    result.expected_rate = _money(expected_rate)
    if expected_rate is not None and invoice_rate is not None:
        result.rate_difference = _money(invoice_rate - expected_rate)

    # --- the comparison ---------------------------------------------------
    if expected_hours is not None and expected_rate is not None:
        expected_amount = (expected_hours * expected_rate).quantize(TWO_PLACES)
        result.expected_amount = _money(expected_amount)
        if invoice_amount is not None:
            result.difference = _money(invoice_amount - expected_amount)

    # --- verdict ----------------------------------------------------------
    if extraction.extraction_status == EXTRACTION_FAILED:
        reasons.append("The invoice could not be read reliably.")

    if reasons:
        result.status = STATUS_REVIEW
    elif result.hours_difference is not None and abs(result.hours_difference) > HOURS_EPSILON:
        result.status = STATUS_MISMATCH
        reasons.append(
            f"The invoice bills {_hours_str(result.invoice_hours)} hours but the "
            f"timesheet records {_hours_str(result.expected_hours)} hours "
            f"({result.hours_difference:+} hours)."
        )
    elif result.rate_difference is not None and abs(result.rate_difference) > MONEY_EPSILON:
        result.status = STATUS_MISMATCH
        reasons.append(
            f"The invoice bills at {_money_str(result.invoice_rate)} per hour but "
            f"the work order sets {_money_str(result.expected_rate)} "
            f"({result.rate_difference:+} per hour)."
        )
    elif result.difference is not None and abs(result.difference) > MONEY_EPSILON:
        result.status = STATUS_MISMATCH
        reasons.append(
            f"The invoice totals {_money_str(result.invoice_amount)} but "
            f"{_hours_str(result.expected_hours)} hours at "
            f"{_money_str(result.expected_rate)} is {_money_str(result.expected_amount)} "
            f"({result.difference:+})."
        )
    else:
        result.status = STATUS_MATCH
        reasons.append(
            f"{_hours_str(result.expected_hours)} hours at "
            f"{_money_str(result.expected_rate)} equals the invoiced "
            f"{_money_str(result.invoice_amount)}."
        )

    result.audit = audit
    result.warnings = warnings
    result.reasons = reasons
    return result


def _timesheet_audit(
    conn: sqlite3.Connection,
    rows: List[sqlite3.Row],
    contractor_id: str,
    year: int,
    month: int,
) -> dict:
    """Run the sibling hours calculator's own checks over these rows."""
    prepared = []
    for row in rows:
        prepared.append({
            "period_year": row["period_year"],
            "period_month": row["period_month"],
            "period_week": row["period_week"],
            "work_date": row["work_date"],
            "week_start": row["week_start"],
            "week_end": row["week_end"],
            "contractor_id": row["contractor_id"],
            "first_name": row["first_name"] or row["c_first"],
            "last_name": row["last_name"] or row["c_last"],
            "supervisor_attuid": row["supervisor_attuid"],
            "vendor_name": row["c_vendor"],
            "segment_name": row["segment_name"],
            "correcting_flag": row["correcting_flag"],
            "regular_hours": row["regular_hours"],
            "ot_hours": row["ot_hours"],
            "week_regular_hours": row["week_regular_hours"],
            "week_ot_hours": row["week_ot_hours"],
        })
    report = report_from_rows(prepared)
    computed = report.compute(contractor_id, year, month)
    data = computed.as_dict()
    data["source_rows"] = [
        {
            "row": row["source_row"],
            "date": row["work_date"],
            "regular_hours": row["regular_hours"],
            "ot_hours": row["ot_hours"],
        }
        for row in rows
    ]
    return data
