# Invoice reconciliation

**Vaibhav Bansal — October 2026**

- Invoice file: `Simple CTI Solutions_Vaibhav Bansal_1001-103126.pdf`
- Invoice number: `Comp2026-11VB`
- Vendor: Simple CTI Solutions, LLC
- Contractor id: `vb771h`
- Status: **REVIEW REQUIRED**

## Amounts

| Item | Value |
| --- | --- |
| Verified billable hours | 176 |
| Hours on the invoice | 176 |
| Contracted hourly rate | n/a |
| Rate on the invoice | 98.00 |
| Expected amount | n/a |
| Invoice amount | 17,248.00 |
| Difference | n/a |
| Currency | USD |

## Findings

- No work order on file for this consultant, so there is no contracted rate to check the invoice against.

## Timesheet

| Item | Value |
| --- | --- |
| Rows used | 22 |
| Total hours | 176.0 |
| Regular hours | 176.0 |
| Overtime hours | 0.0 |
| Days recorded | 22 |
| Full-month benchmark | 176.0 |


---

Generated 2026-11-20T15:50:02+00:00 by the invoice-reconciliation engine.
