# INVOICE

Indotronix International Corporation 687 Lee Road, Suite 250. Rochester , NY 14606 - USA . Receivables@iic.com

www.iic.com

- **CompNova Inc:** **Invoice #:** 57977W

300 N Coit Road Suite 340  
**Invoice Date:** 11/17/2026  
Richardson  
**Invoice Due Date:** 01/01/2027  
Texas  
**Invoice Shipped Date:** 11/17/2026  
75080

Location:  
**Terms:** Net 45

| # | Services Summary | Activity | Quantity | Rate | Class | Amount |
| --- | --- | --- | --- | --- | --- | --- |
|  | 1. Harish Giriraju | Computer Software Services 10/01/2026 - 10/31/2026 | 160 | 73.00 | TX:ITS | 11680.00 |

- **Subtotal:** **11680.00 USD**
- **Total:** **11680.00 USD**

Page 1/1

Powered by TCPDF (www.tcpdf.org)
