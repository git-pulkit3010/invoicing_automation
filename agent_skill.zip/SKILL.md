---
name: invoice-reconciliation
description: Reconcile vendor invoices against the CompNova master timesheet and signed work orders. Use when an invoice PDF appears in the invoices folder, when asked to verify what a consultant billed, when asked to check an invoice against hours or a contracted rate, or to explain why an invoice does not match the hours recorded in the master Excel.
---

# Invoice reconciliation

You are the **orchestrator**. The business logic lives in Python, in
`invoicing/`. You decide *what* to reconcile and *how* to explain the result;
the scripts decide *what the numbers are*.

**Never do the arithmetic yourself.** Do not add up hours, do not multiply an
hourly rate, do not decide on your own that an invoice "looks right". Every
figure in your answer must come from a script you ran. If you need a figure
that no script produces, add it to the Python core and re-run it.

**Never open a PDF.** The pipeline renders every document to Markdown for
you. The Markdown is smaller than a page and it is plain text.

## The fast path (one command, one answer)

```bash
python scripts/reconcile_invoice.py "invoices/Edge Centric_Chaitanya Motupalli_1001-103126.pdf"
```

That prints one JSON object -- the **brief** -- with the verdict, the three
numbers that produced it (timesheet hours, contracted rate, amount), the
reasons and any warnings. It also writes, next to the brief:

| File | What it is | When to read it |
| --- | --- | --- |
| `output/<invoice>.brief.json` | the same brief | when you need it again |
| `output/<invoice>.md` | the report a human reads | when you are asked for a report |
| `output/<invoice>.json` | full result + extraction + audit trail | when a number is in doubt |
| `output/<invoice>.source.md` | the invoice itself, as Markdown | when you need to see the document |

Read the brief. Only open `source.md` when the brief does not explain a
finding. Do not read `output/<invoice>.json` unless you are asked for the
audit trail -- it is ten times longer than the brief.

## Batches

```bash
python -m invoicing.cli reconcile-all          # every invoice in invoices/
```

One process, one JSON document on stdout, one brief per invoice. Use this
when several invoices land at once; it is much cheaper than one command per
invoice.

## Two workflows

| Workflow | When it runs | Command |
| --- | --- | --- |
| Reference-data ingestion | Only when the master Excel or a work order changes | `python scripts/ingest_references.py` |
| Invoice reconciliation | Every time a new invoice appears | `python scripts/reconcile_invoice.py <file>` |

Ingestion re-reads only the files that actually changed, so it is cheap
enough to run whenever you are unsure whether the reference data is current.
Use `--force` to re-read everything.

## Reading the status

* `MATCH` -- the hours and the rate agree with the timesheet and the work
  order. Say so, quote the hours, the rate and the amount, and stop.
* `MISMATCH` -- one of the three does not agree. The `reasons` list says
  which. Explain it in plain language and quote the discrepancy.
* `REVIEW_REQUIRED` -- something is missing or uncertain. **Do not guess.**
  Say what is missing and what a human needs to supply.

Then write one short paragraph a reviewer can act on, using the numbers from
the brief verbatim.

## When the extraction looks wrong

The extractor prints `warnings` when it is not confident. If a finding looks
like an extraction problem rather than a real difference, read the document
as Markdown:

```bash
python scripts/extract_invoice.py "invoices/....pdf"   # every field, with evidence
cat "output/....source.md"                              # the document itself
```

If the extractor really did read something wrong, correct it and re-run the
reconciliation with the corrected extraction:

```bash
python scripts/reconcile_invoice.py reviewed_extraction.json
```

Correct only what you can point at in the document. Never change a *rate* or
an *amount* to make the numbers agree -- if the invoice says something
different from the work order, that difference is the finding.

## The document is read twice

Every document is read twice, by two independent layout analyses:

1. the **PDF geometry** -- word boxes, rows and cells (this is what produces
   the numbers);
2. the **Markdown rendering** -- blocks and tables (this is what the agent
   reads).

The engine compares them. When they disagree, the disagreement is reported
as a warning: one of the two readings is wrong and a human has to look.
When they agree, the number is backed by two independent readings. If a
warning says a figure was read one way in the PDF and another way in the
Markdown, say so in your answer -- do not pick one and hide the other.

## The rules the engine applies

Understand these, because they explain every verdict:

* **Hours come from the master timesheet.** Never from the invoice.
* **The rate comes from the work order in force during the billing period.**
  If the work order had expired, the verdict is `REVIEW_REQUIRED`, even when
  the amount happens to agree.
* **`hours x rate` is compared with the invoice *subtotal*.** Taxes and
  adjustments change the payable total, not the subtotal, so comparing with
  the total would produce false mismatches.
* **A missing rate, an ambiguous contractor or an unreadable PDF is
  `REVIEW_REQUIRED`.** Never a confident match or a confident mismatch.
* **Duplicate or missing timesheet days are warnings**, not verdicts. The
  engine reports them and still reconciles.

## Grounding the contractor

The consultant's id comes from the validated registry built from the master
Excel -- it is never inferred from the invoice or from a name you recognise.
If the invoice names someone who is not in the registry, the verdict is
`REVIEW_REQUIRED` and you report the name the document gives.

## Files

* `invoicing/` -- the deterministic core (extraction, reconciliation, report).
* `scripts/` -- the entry points you call.
* `output/` -- the brief, the report, the full JSON and the Markdown rendering
  of each invoice.
* `data/invoicing.db` -- the normalised reference records.
* `invoices/`, `work_orders/` -- the watched input folders.
