#!/usr/bin/env bash
#
# Install the invoice-reconciliation skill into the Codex skill directory so
# that Codex can pick it up (it is listed under ~/.codex/skills).
#
#   ./scripts/install_skill.sh            # install
#   ./scripts/install_skill.sh --force    # replace an existing installation
#
# The skill drives the Python pipeline that lives in this project folder, so
# the installed copy records where that folder is.
set -euo pipefail

SKILL_NAME="invoice-reconciliation"
REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
CODEX_HOME="${CODEX_HOME:-$HOME/.codex}"
DEST="$CODEX_HOME/skills/$SKILL_NAME"
FORCE=0

if [ "${1:-}" = "--force" ]; then
    FORCE=1
fi

if [ -e "$DEST" ] && [ "$FORCE" -ne 1 ]; then
    echo "$DEST already exists. Re-run with --force to replace it."
    exit 1
fi

mkdir -p "$DEST"
cp "$REPO_ROOT/SKILL.md" "$DEST/SKILL.md"
cp "$REPO_ROOT/README.md" "$DEST/README.md" 2>/dev/null || true

# The pipeline lives in the project folder; tell the agent where it is and
# which interpreter to use.
{
    echo
    echo "## This installation"
    echo
    echo "The deterministic pipeline this skill drives lives in:"
    echo
    echo '```'
    echo "$REPO_ROOT"
    echo '```'
    echo
    echo "Run every command from that folder, with its virtual environment:"
    echo
    echo '```bash'
    echo "cd \"$REPO_ROOT\""
    echo ".venv/bin/python scripts/reconcile_invoice.py \"invoices/<invoice>.pdf\""
    echo ".venv/bin/python -m invoicing.cli reconcile-all"
    echo '```'
} >> "$DEST/SKILL.md"

echo "Installed $SKILL_NAME into $DEST"
echo "It is available to Codex from the next turn."
