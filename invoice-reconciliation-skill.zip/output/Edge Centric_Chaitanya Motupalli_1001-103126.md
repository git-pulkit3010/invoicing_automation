# Invoice reconciliation

**Chaitanya Motupalli — October 2026**

- Invoice file: `Edge Centric_Chaitanya Motupalli_1001-103126.pdf`
- Invoice number: `1290`
- Vendor: Edge Centric, LLC
- Contractor id: `cx6008`
- Status: **MATCH**

## Amounts

| Item | Value |
| --- | --- |
| Verified billable hours | 152 |
| Hours on the invoice | 152 |
| Contracted hourly rate | 100.00 |
| Rate on the invoice | 100.00 |
| Expected amount | 15,200.00 |
| Invoice amount | 15,200.00 |
| Difference | +0.00 |
| Currency | USD |

## Findings

- 152 hours at 100.00 equals the invoiced 15,200.00.

## Work order

| Item | Value |
| --- | --- |
| File | `Chaitanya Motupalli Vendor_Work_Order_CN.pdf` |
| Reference | PLC-3482 |
| Vendor | Edge Centric LLC |
| Consultant | Chaitanya Motupalli |
| Billing rate | USD 100 hourly |
| Rate unit | hourly |
| Effective from | 04/07/26 |
| Effective to | 12/31/26 |
| Covers the billing period | yes |

## Timesheet

| Item | Value |
| --- | --- |
| Rows used | 19 |
| Total hours | 152.0 |
| Regular hours | 152.0 |
| Overtime hours | 0.0 |
| Days recorded | 19 |
| Full-month benchmark | 176.0 |

- Missing weekdays: 3 weekday(s) in the period have no entry (2026-10-23, 2026-10-29, 2026-10-30).

---

Generated 2026-11-20T15:50:02+00:00 by the invoice-reconciliation engine.
