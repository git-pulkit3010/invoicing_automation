"""CompNova invoice-reconciliation core.

This package holds every piece of *business logic* used by the invoice
reconciliation workflow.  Everything here is deterministic and unit-testable:
no LLM calls, no network access, no hidden state.

The agent (see ``SKILL.md``) is the orchestrator.  It reads the documents,
resolves ambiguity and explains exceptions -- but it never performs the
arithmetic.  The arithmetic lives in :mod:`invoicing.reconcile`.
"""

from __future__ import annotations

__version__ = "1.0.0"

__all__ = ["__version__"]
