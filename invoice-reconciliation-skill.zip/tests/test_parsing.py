"""Unit tests for the value parsers and the PDF extraction layer."""

from __future__ import annotations

import sys
import unittest
from decimal import Decimal
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(BASE_DIR))

from invoicing.extract import (  # noqa: E402
    extract_consultant_name,
    extract_invoice,
    extract_work_order,
)
from invoicing.textutil import (  # noqa: E402
    norm_name,
    parse_amount,
    parse_month,
    parse_number,
)

INVOICES = BASE_DIR / "invoices"
WORK_ORDERS = BASE_DIR / "work_orders"


class TestValueParsing(unittest.TestCase):
    def test_parse_amount_handles_grouped_and_ungrouped_digits(self):
        self.assertEqual(parse_amount("$15,200.00"), Decimal("15200.00"))
        self.assertEqual(parse_amount("11680.00 USD"), Decimal("11680.00"))
        self.assertEqual(parse_amount("17,248.00"), Decimal("17248.00"))
        self.assertEqual(parse_amount("$ 17,248.00"), Decimal("17248.00"))
        self.assertEqual(parse_amount("98.00"), Decimal("98.00"))

    def test_parse_amount_rejects_non_numbers(self):
        self.assertIsNone(parse_amount("Total"))
        self.assertIsNone(parse_amount(""))

    def test_parse_number(self):
        self.assertEqual(parse_number("176.00"), Decimal("176.00"))
        self.assertEqual(parse_number("152"), Decimal("152"))
        self.assertIsNone(parse_number("USD"))

    def test_norm_name(self):
        self.assertEqual(norm_name("Chaitanya KUMAR Nara"), "CHAITANYA KUMAR NARA")
        self.assertEqual(norm_name("  harish   giriraju "), "HARISH GIRIRAJU")
        self.assertEqual(norm_name("Edge Centric, LLC"), "EDGE CENTRIC LLC")

    def test_parse_month(self):
        self.assertEqual(parse_month("Oct 2026"), (2026, 10))
        self.assertEqual(parse_month("October 2026"), (2026, 10))
        self.assertEqual(parse_month("10/01/2026 - 10/31/2026"), (2026, 10))
        self.assertIsNone(parse_month("no period here"))


class TestConsultantName(unittest.TestCase):
    def test_title_pattern(self):
        self.assertEqual(
            extract_consultant_name("Consulting Vaibhav Bansal"), "Vaibhav Bansal"
        )

    def test_plain_name(self):
        self.assertEqual(extract_consultant_name("Harish Giriraju"), "Harish Giriraju")

    def test_label_words_are_not_names(self):
        self.assertNotEqual(extract_consultant_name("Total Amount Due"), "Total Amount Due")


class TestWorkOrderExtraction(unittest.TestCase):
    """The four work orders are the same form filled in by four vendors."""

    EXPECTED = {
        "Chaitanya Motupalli Vendor_Work_Order_CN.pdf": {
            "consultant_name": "Chaitanya Motupalli",
            "vendor_name": "Edge Centric LLC",
            "billing_rate": "USD 100 hourly",
            "client_name": "AT&T",
            "start_date": "04/07/26",
            "end_date": "12/31/26",
            "net_days": "45",
        },
        "Chaitanya Nara Vendor_Work_Order_CN.pdf": {
            "consultant_name": "Chaitanya KUMAR Nara",
            "vendor_name": "VMC Soft Technologies Inc",
            "billing_rate": "USD 71 hourly",
            "start_date": "03/17/25",
            "end_date": "03/17/26",
        },
        "Harish Giriraju Vendor_Work_Order_CN.pdf": {
            "consultant_name": "Harish Giriraju",
            "vendor_name": "Indotronix International Corporation",
            "billing_rate": "USD 73 hourly",
            "start_date": "04/08/25",
            "end_date": "03/31/26",
        },
        "Srilasya Samudrala Vendor_Work_Order_CN.pdf": {
            "consultant_name": "Srilasya Samudrala",
            "vendor_name": "ITEK INFO",
            "billing_rate": "USD 83 hourly",
            "start_date": "12/29/25",
            "end_date": "12/31/26",
        },
    }

    def test_form_fields(self):
        for filename, expected in self.EXPECTED.items():
            with self.subTest(filename):
                extraction = extract_work_order(WORK_ORDERS / filename)
                for field, value in expected.items():
                    self.assertEqual(
                        getattr(extraction, field).value, value,
                        f"{filename}: {field}",
                    )
                self.assertEqual(extraction.extraction_status, "verified")

    def test_rate_unit_is_hourly(self):
        for filename in self.EXPECTED:
            with self.subTest(filename):
                extraction = extract_work_order(WORK_ORDERS / filename)
                self.assertEqual(extraction.rate_unit.value, "hourly")


class TestInvoiceExtraction(unittest.TestCase):
    """Four vendors, four layouts, one extraction routine."""

    EXPECTED = {
        "Edge Centric_Chaitanya Motupalli_1001-103126.pdf": {
            "invoice_number": "1290",
            "invoice_date": "Nov 12, 2026",
            "billing_period": "Oct 2026",
            "subtotal": "$15,200.00",
            "total": "$15,200.00",
            "period": (2026, 10),
            "line": (Decimal("152"), Decimal("100.00"), Decimal("15200.00")),
            "description": "Chaitanya Motupalli",
        },
        "Indotronix International Corporation_Harish Giriraju_1001-103126.pdf": {
            "invoice_number": "57977W",
            "invoice_date": "11/17/2026",
            "billing_period": "10/01/2026 - 10/31/2026",
            "period": (2026, 10),
            "line": (Decimal("160"), Decimal("73.00"), Decimal("11680.00")),
            "description": "Harish Giriraju",
        },
        "Itek Info_Srilasya Samudrala_1001-103126.pdf": {
            "invoice_number": "1841",
            "invoice_date": "11/12/2026",
            "billing_period": "October 2026",
            "total": "$14,608.00",
            "period": (2026, 10),
            "line": (Decimal("176"), Decimal("83.00"), Decimal("14608.00")),
            "description": "Srilasya Samudrala",
        },
        "Simple CTI Solutions_Vaibhav Bansal_1001-103126.pdf": {
            "invoice_number": "Comp2026-11VB",
            "invoice_date": "November 1, 2026",
            "billing_period": "10/01/2026 - 10/31/2026",
            "period": (2026, 10),
            "line": (Decimal("176.00"), Decimal("98.00"), Decimal("17248.00")),
            "description": "Consulting Vaibhav Bansal",
        },
    }

    def test_invoice_fields(self):
        for filename, expected in self.EXPECTED.items():
            with self.subTest(filename):
                extraction = extract_invoice(INVOICES / filename)
                self.assertEqual(extraction.invoice_number.value, expected["invoice_number"])
                self.assertEqual(extraction.invoice_date.value, expected["invoice_date"])
                self.assertEqual(extraction.billing_period.value, expected["billing_period"])
                self.assertEqual(
                    (extraction.period_year, extraction.period_month), expected["period"]
                )
                if "subtotal" in expected:
                    self.assertEqual(extraction.subtotal.value, expected["subtotal"])
                if "total" in expected:
                    self.assertEqual(extraction.total.value, expected["total"])

    def test_line_items(self):
        for filename, expected in self.EXPECTED.items():
            with self.subTest(filename):
                extraction = extract_invoice(INVOICES / filename)
                self.assertEqual(len(extraction.line_items), 1)
                item = extraction.line_items[0]
                self.assertEqual(
                    (item.quantity, item.unit_rate, item.amount), expected["line"]
                )
                self.assertTrue(item.arithmetic_consistent)
                self.assertEqual(item.description, expected["description"])

    def test_extraction_has_no_warnings(self):
        for filename in self.EXPECTED:
            with self.subTest(filename):
                extraction = extract_invoice(INVOICES / filename)
                self.assertEqual(extraction.warnings, [])
                self.assertEqual(extraction.extraction_status, "verified")


if __name__ == "__main__":
    unittest.main()
