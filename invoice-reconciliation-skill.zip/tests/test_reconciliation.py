"""Tests for the reconciliation engine.

The engine tests run against a small synthetic database so that every
verdict -- match, mismatch and review-required -- is pinned down precisely.
The end-to-end test then runs the real files through the whole pipeline.
"""

from __future__ import annotations

import sys
import tempfile
import unittest
from decimal import Decimal
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(BASE_DIR))

from invoicing.db import connect  # noqa: E402
from invoicing.extract import extract_invoice  # noqa: E402
from invoicing.ingest import ingest_excel, ingest_work_orders, load_roster  # noqa: E402
from invoicing.models import (  # noqa: E402
    STATUS_MATCH,
    STATUS_MISMATCH,
    STATUS_REVIEW,
    FieldValue,
    InvoiceExtraction,
    LineItem,
)
from invoicing.reconcile import reconcile  # noqa: E402

INVOICES = BASE_DIR / "invoices"
WORK_ORDERS = BASE_DIR / "work_orders"


def make_extraction(**overrides) -> InvoiceExtraction:
    """A synthetic October 2026 invoice for a 160-hour consultant."""
    extraction = InvoiceExtraction(
        source_file="Synthetic Invoice.pdf",
        vendor_name=FieldValue(value=overrides.pop("vendor_name", "Synthetic Vendor LLC")),
        contractor_name=FieldValue(value=overrides.pop("contractor_name", "Test Contractor")),
        contractor_id=FieldValue(value=overrides.pop("contractor_id", "tc0001")),
        invoice_number=FieldValue(value=overrides.pop("invoice_number", "INV-1")),
        billing_period=FieldValue(value="October 2026"),
        period_year=2026,
        period_month=10,
        currency=FieldValue(value="USD"),
        subtotal=FieldValue(value=overrides.pop("subtotal", "$11,680.00")),
        total=FieldValue(value=overrides.pop("total", "$11,680.00")),
        line_items=[
            LineItem(
                description="Test Contractor",
                quantity=Decimal("160"),
                unit_rate=Decimal("73.00"),
                amount=Decimal("11680.00"),
                arithmetic_consistent=True,
            )
        ],
        extraction_status="verified",
    )
    for key, value in overrides.items():
        setattr(extraction, key, value)
    return extraction


class ReconciliationTestCase(unittest.TestCase):
    """Builds a small database with one consultant and one work order."""

    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.db_path = Path(self._tmp.name) / "test.db"
        self.conn = connect(self.db_path)
        self.conn.execute(
            "INSERT INTO contractors (contractor_id, first_name, last_name, "
            "full_name, normalized_name, vendor_name) "
            "VALUES ('tc0001', 'Test', 'Contractor', 'Test Contractor', "
            "'TEST CONTRACTOR', 'COMPNOVA LLC')"
        )
        for day in (1, 2, 5, 6, 7, 8, 9, 12, 13, 14, 15, 16, 19, 20, 21, 22, 23, 26, 27, 28):
            self.conn.execute(
                "INSERT INTO timesheet_entries (contractor_id, work_date, period_year, "
                "period_month, period_week, week_start, week_end, regular_hours, "
                "ot_hours, total_hours, correcting_flag, first_name, last_name) "
                "VALUES ('tc0001', ?, 2026, 10, '1', '2026-09-27', '2026-10-03', 8, 0, 8, 'N', "
                "'TEST', 'CONTRACTOR')",
                (f"2026-10-{day:02d}",),
            )
        self.conn.commit()

    def tearDown(self):
        self.conn.close()
        self._tmp.cleanup()

    def add_work_order(self, rate="73", start="2025-04-08", end="2026-03-31",
                       consultant_id="tc0001"):
        self.conn.execute(
            "INSERT INTO work_orders (source_file, source_sha256, work_order_ref, "
            "vendor_name, consultant_name, consultant_id, billing_rate, rate_unit, "
            "client_name, start_date, end_date, net_days, page_count, "
            "extraction_status, extracted_json, ingested_at) "
            "VALUES ('wo.pdf', 'sha', 'WO-1', 'Synthetic Vendor LLC', "
            "'Test Contractor', ?, ?, 'hourly', 'AT&T', ?, ?, 45, 2, 'verified', '{}', ?)",
            (consultant_id, f"USD {rate} hourly", start, end, "2026-01-01T00:00:00"),
        )
        self.conn.commit()


class TestVerdicts(ReconciliationTestCase):
    def test_match(self):
        self.add_work_order(start="2025-04-08", end="2026-12-31")
        result = reconcile(self.conn, make_extraction())
        self.assertEqual(result.status, STATUS_MATCH)
        self.assertEqual(result.expected_hours, Decimal("160.00"))
        self.assertEqual(result.expected_rate, Decimal("73.00"))
        self.assertEqual(result.expected_amount, Decimal("11680.00"))
        self.assertEqual(result.invoice_amount, Decimal("11680.00"))
        self.assertEqual(result.difference, Decimal("0.00"))

    def test_mismatch_on_hours(self):
        self.add_work_order(start="2025-04-08", end="2026-12-31")
        extraction = make_extraction()
        extraction.line_items[0].quantity = Decimal("170")
        extraction.line_items[0].amount = Decimal("12410.00")
        extraction.subtotal.value = "$12,410.00"
        extraction.total.value = "$12,410.00"
        result = reconcile(self.conn, extraction)
        self.assertEqual(result.status, STATUS_MISMATCH)
        self.assertEqual(result.hours_difference, Decimal("10.00"))
        self.assertTrue(any("hours" in reason for reason in result.reasons))

    def test_mismatch_on_rate(self):
        self.add_work_order(rate="70", start="2025-04-08", end="2026-12-31")
        result = reconcile(self.conn, make_extraction())
        self.assertEqual(result.status, STATUS_MISMATCH)
        self.assertEqual(result.rate_difference, Decimal("3.00"))
        self.assertEqual(result.expected_amount, Decimal("11200.00"))

    def test_review_required_when_no_work_order(self):
        result = reconcile(self.conn, make_extraction())
        self.assertEqual(result.status, STATUS_REVIEW)
        self.assertTrue(any("work order" in reason.lower() for reason in result.reasons))
        self.assertIsNone(result.expected_rate)

    def test_review_required_when_work_order_expired(self):
        self.add_work_order(start="2025-04-08", end="2026-03-31")
        result = reconcile(self.conn, make_extraction())
        self.assertEqual(result.status, STATUS_REVIEW)
        self.assertTrue(
            any("expired" in warning for warning in result.warnings),
            result.warnings,
        )

    def test_review_required_when_contractor_unknown(self):
        self.add_work_order(start="2025-04-08", end="2026-12-31")
        extraction = make_extraction(contractor_id="")
        result = reconcile(self.conn, extraction)
        self.assertEqual(result.status, STATUS_REVIEW)
        self.assertTrue(
            any("matched to a record" in reason for reason in result.reasons)
        )

    def test_review_required_when_period_missing(self):
        self.add_work_order(start="2025-04-08", end="2026-12-31")
        extraction = make_extraction()
        extraction.period_year = None
        extraction.period_month = None
        result = reconcile(self.conn, extraction)
        self.assertEqual(result.status, STATUS_REVIEW)
        self.assertTrue(any("billing period" in reason for reason in result.reasons))

    def test_missing_timesheet_is_review_required(self):
        self.add_work_order(start="2025-04-08", end="2026-12-31")
        self.conn.execute("DELETE FROM timesheet_entries")
        self.conn.commit()
        result = reconcile(self.conn, make_extraction())
        self.assertEqual(result.status, STATUS_REVIEW)
        self.assertTrue(any("no entries" in reason for reason in result.reasons))


class TestEndToEnd(unittest.TestCase):
    """The real sample folder, through the real pipeline."""

    @classmethod
    def setUpClass(cls):
        cls._tmp = tempfile.TemporaryDirectory()
        cls.db_path = Path(cls._tmp.name) / "e2e.db"
        cls.conn = connect(cls.db_path)
        ingest_excel(cls.conn, BASE_DIR / "CMPM Report_1001-103126_Final.xlsx")
        ingest_work_orders(cls.conn, WORK_ORDERS)
        cls.conn.commit()
        cls.roster = load_roster(cls.conn)

    @classmethod
    def tearDownClass(cls):
        cls.conn.close()
        cls._tmp.cleanup()

    def reconcile_file(self, filename):
        extraction = extract_invoice(INVOICES / filename, self.roster)
        return extraction, reconcile(self.conn, extraction)

    def test_roster_is_loaded(self):
        self.assertEqual(len(self.roster), 133)
        self.assertTrue(any(c.contractor_id == "hg5064" for c in self.roster))

    def test_edge_centric_matches(self):
        extraction, result = self.reconcile_file(
            "Edge Centric_Chaitanya Motupalli_1001-103126.pdf"
        )
        self.assertEqual(result.contractor_id, "cx6008")
        self.assertEqual(result.status, STATUS_MATCH)
        self.assertEqual(result.expected_hours, Decimal("152.00"))
        self.assertEqual(result.expected_rate, Decimal("100.00"))
        self.assertEqual(result.expected_amount, Decimal("15200.00"))
        self.assertEqual(result.invoice_amount, Decimal("15200.00"))

    def test_itek_matches(self):
        extraction, result = self.reconcile_file(
            "Itek Info_Srilasya Samudrala_1001-103126.pdf"
        )
        self.assertEqual(result.contractor_id, "sx4462")
        self.assertEqual(result.status, STATUS_MATCH)
        self.assertEqual(result.expected_hours, Decimal("176.00"))
        self.assertEqual(result.expected_rate, Decimal("83.00"))

    def test_harish_needs_review_because_work_order_expired(self):
        extraction, result = self.reconcile_file(
            "Indotronix International Corporation_Harish Giriraju_1001-103126.pdf"
        )
        self.assertEqual(result.contractor_id, "hg5064")
        self.assertEqual(result.status, STATUS_REVIEW)
        # The arithmetic still agrees; it is the contract coverage that fails.
        self.assertEqual(result.expected_hours, Decimal("160.00"))
        self.assertEqual(result.invoice_amount, Decimal("11680.00"))

    def test_vaibhav_needs_review_because_no_work_order(self):
        extraction, result = self.reconcile_file(
            "Simple CTI Solutions_Vaibhav Bansal_1001-103126.pdf"
        )
        self.assertEqual(result.contractor_id, "vb771h")
        self.assertEqual(result.status, STATUS_REVIEW)
        self.assertIsNone(result.expected_rate)
        self.assertEqual(result.expected_hours, Decimal("176.00"))

    def test_all_invoices_resolve_a_contractor(self):
        for path in sorted(INVOICES.glob("*.pdf")):
            if path.name.endswith(":Zone.Identifier"):
                continue
            with self.subTest(path.name):
                extraction = extract_invoice(path, self.roster)
                self.assertTrue(extraction.contractor_id.present(), path.name)
                self.assertEqual(extraction.warnings, [], path.name)


if __name__ == "__main__":
    unittest.main()
