#!/usr/bin/env python3
"""Reconcile one invoice against the master timesheet and work orders.

The script extracts the invoice, looks the consultant up in the validated
contractor registry, calculates the expected amount and writes both a JSON
result and a Markdown report.  Every number in the verdict is computed here,
never in the prompt.

    python scripts/reconcile_invoice.py "invoices/Some Vendor_Ann Lee_1001-103126.pdf"

To re-run with an extraction the agent has reviewed and corrected, pass the
corrected JSON instead of the PDF:

    python scripts/reconcile_invoice.py reviewed_extraction.json
"""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from invoicing.cli import main  # noqa: E402

if __name__ == "__main__":
    raise SystemExit(main(["reconcile-invoice", *sys.argv[1:]]))
