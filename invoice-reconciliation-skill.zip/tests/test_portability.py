"""Installation and source-cache behavior with an external, movable data root."""

import json
import os
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from scripts import install_skill


class TestExternalDataRoot(unittest.TestCase):
    def test_installed_skill_uses_external_data_after_both_folders_move(self):
        with tempfile.TemporaryDirectory() as tmp:
            temp = Path(tmp)
            data_root = temp / "data-original"
            data_root.mkdir()
            for name in ("data", "invoices", "work_orders"):
                shutil.copytree(ROOT / name, data_root / name)
            for workbook in ROOT.glob("*.xlsx"):
                shutil.copy2(workbook, data_root / workbook.name)

            args = install_skill.build_parser().parse_args([
                "install", "--dir", str(temp / "skills"),
                "--project-root", str(data_root), "--skip-deps",
            ])
            with patch.object(install_skill, "ensure_venv", return_value=Path(sys.executable)):
                self.assertEqual(install_skill.cmd_install(args), 0)

            installed = temp / "skills" / "invoice-reconciliation"
            self.assertFalse((installed / "data").exists())
            self.assertFalse((installed / "invoices").exists())
            self.assertFalse((installed / "work_orders").exists())
            self.assertFalse(list(installed.glob("*.xlsx")))
            settings = json.loads((installed / "install.json").read_text())
            self.assertEqual(settings["code_root"], ".")
            self.assertEqual(settings["project_root"], str(data_root))

            moved_skill = temp / "relocated-skill"
            moved_data = temp / "relocated-data"
            installed.rename(moved_skill)
            data_root.rename(moved_data)
            env = dict(os.environ, INVOICING_PROJECT_ROOT=str(moved_data), PYTHONPATH="")
            runner = moved_skill / "scripts" / "run_pipeline.py"

            status = subprocess.run(
                [sys.executable, str(runner), "status"], cwd=temp,
                env=env, capture_output=True, text=True, check=True,
            )
            payload = json.loads(status.stdout)
            self.assertEqual(Path(payload["database"]), moved_data / "data" / "invoicing.db")
            self.assertEqual(payload["counts"]["work_orders"], 4)

            ingest = subprocess.run(
                [sys.executable, str(runner), "ingest"], cwd=temp,
                env=env, capture_output=True, text=True, check=True,
            )
            refresh = json.loads(ingest.stdout)
            self.assertEqual(refresh["excel"]["unchanged"], 1)
            self.assertEqual(refresh["work_orders"]["unchanged"], 4)

            batch = subprocess.run(
                [sys.executable, str(runner), "reconcile-all"], cwd=temp,
                env=env, capture_output=True, text=True, check=True,
            )
            self.assertEqual(json.loads(batch.stdout)["processed"], 4)

    def test_invoice_override_is_read_by_config(self):
        with tempfile.TemporaryDirectory() as tmp:
            env = dict(os.environ, INVOICES_DIR=tmp)
            result = subprocess.run(
                [sys.executable, "-c",
                 "from invoicing.config import INVOICES_DIR; print(INVOICES_DIR)"],
                cwd=ROOT, env=env, capture_output=True, text=True, check=True,
            )
            self.assertEqual(Path(result.stdout.strip()), Path(tmp))

    def test_wrapper_rejects_an_empty_data_root(self):
        with tempfile.TemporaryDirectory() as tmp:
            env = dict(os.environ, INVOICING_PROJECT_ROOT=tmp)
            runner = ROOT / "scripts" / "run_pipeline.py"
            result = subprocess.run(
                [sys.executable, str(runner), "status"], cwd=tmp,
                env=env, capture_output=True, text=True,
            )
            self.assertNotEqual(result.returncode, 0)
            self.assertIn("reference database is missing", result.stderr)
            self.assertFalse((Path(tmp) / "data" / "invoicing.db").exists())


if __name__ == "__main__":
    unittest.main()
