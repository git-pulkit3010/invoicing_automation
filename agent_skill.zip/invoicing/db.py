"""SQLite storage for the normalised records described in the architecture doc.

Three logical tables hold the reference data -- contractors, timesheet
entries and work orders -- plus invoices, processing history and
reconciliation results.  All money is stored as text/REAL only for display;
the reconciliation arithmetic itself uses :class:`decimal.Decimal`.
"""

from __future__ import annotations

import hashlib
import sqlite3
from contextlib import contextmanager
from pathlib import Path
from typing import Iterator, Optional

from .config import DB_PATH, ensure_dirs

SCHEMA_VERSION = 1

SCHEMA = """
CREATE TABLE IF NOT EXISTS meta (
    key   TEXT PRIMARY KEY,
    value TEXT
);

-- Table 1: Contractor / work order registry.
CREATE TABLE IF NOT EXISTS contractors (
    contractor_id    TEXT PRIMARY KEY,
    first_name       TEXT NOT NULL DEFAULT '',
    last_name        TEXT NOT NULL DEFAULT '',
    full_name        TEXT NOT NULL DEFAULT '',
    normalized_name  TEXT NOT NULL DEFAULT '',
    vendor_name      TEXT NOT NULL DEFAULT ''
);

-- Table 2: Master timesheet records, imported from the Excel report.
CREATE TABLE IF NOT EXISTS timesheet_entries (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    contractor_id   TEXT NOT NULL,
    work_date       TEXT NOT NULL,
    period_year     INTEGER NOT NULL,
    period_month    INTEGER NOT NULL,
    period_week     TEXT,
    week_start      TEXT,
    week_end        TEXT,
    regular_hours   REAL NOT NULL DEFAULT 0,
    ot_hours        REAL NOT NULL DEFAULT 0,
    total_hours     REAL NOT NULL DEFAULT 0,
    correcting_flag TEXT,
    first_name      TEXT,
    last_name       TEXT,
    supervisor_attuid TEXT,
    segment_name    TEXT,
    week_regular_hours REAL,
    week_ot_hours    REAL,
    source_file     TEXT,
    source_row      INTEGER,
    FOREIGN KEY (contractor_id) REFERENCES contractors (contractor_id)
);

CREATE INDEX IF NOT EXISTS idx_timesheet_contractor
    ON timesheet_entries (contractor_id, period_year, period_month);

CREATE TABLE IF NOT EXISTS work_orders (
    id                INTEGER PRIMARY KEY AUTOINCREMENT,
    source_file       TEXT NOT NULL UNIQUE,
    source_sha256     TEXT,
    work_order_ref    TEXT,
    vendor_name       TEXT,
    consultant_name   TEXT,
    consultant_id     TEXT,
    billing_rate      TEXT,
    rate_unit         TEXT,
    client_name       TEXT,
    start_date        TEXT,
    end_date          TEXT,
    net_days          INTEGER,
    page_count        INTEGER,
    extraction_status TEXT,
    extracted_json    TEXT,
    ingested_at       TEXT
);

-- Table 3: Extracted invoices.
CREATE TABLE IF NOT EXISTS invoices (
    id                INTEGER PRIMARY KEY AUTOINCREMENT,
    source_file       TEXT NOT NULL UNIQUE,
    source_sha256     TEXT,
    page_count        INTEGER,
    vendor_name       TEXT,
    customer_name     TEXT,
    contractor_name   TEXT,
    contractor_id     TEXT,
    invoice_number    TEXT,
    invoice_date      TEXT,
    due_date          TEXT,
    billing_period    TEXT,
    period_year       INTEGER,
    period_month      INTEGER,
    currency          TEXT,
    subtotal          TEXT,
    tax               TEXT,
    total             TEXT,
    amount_due        TEXT,
    extraction_status TEXT,
    extracted_json    TEXT,
    processed_at      TEXT
);

-- Source metadata: lets reference data be re-ingested only when it changes.
CREATE TABLE IF NOT EXISTS source_files (
    path         TEXT PRIMARY KEY,
    kind         TEXT NOT NULL,
    sha256       TEXT NOT NULL,
    size_bytes   INTEGER,
    modified_at  REAL,
    processed_at TEXT
);

CREATE TABLE IF NOT EXISTS reconciliation_results (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    invoice_file  TEXT NOT NULL,
    invoice_sha256 TEXT,
    status        TEXT NOT NULL,
    contractor_id TEXT,
    result_json   TEXT NOT NULL,
    created_at    TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_recon_invoice
    ON reconciliation_results (invoice_file, created_at);
"""


def sha256_file(path: Path) -> str:
    """Return the SHA-256 hex digest of a file."""
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def connect(db_path: Optional[Path] = None) -> sqlite3.Connection:
    """Open the database and make sure the schema exists."""
    ensure_dirs()
    path = Path(db_path) if db_path else DB_PATH
    path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(path))
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    conn.executescript(SCHEMA)
    conn.execute(
        "INSERT INTO meta (key, value) VALUES ('schema_version', ?) "
        "ON CONFLICT (key) DO UPDATE SET value = excluded.value",
        (str(SCHEMA_VERSION),),
    )
    conn.commit()
    return conn


@contextmanager
def session(db_path: Optional[Path] = None) -> Iterator[sqlite3.Connection]:
    """Context manager that commits on success and rolls back on error."""
    conn = connect(db_path)
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def record_source(
    conn: sqlite3.Connection,
    path: Path,
    kind: str,
    processed_at: str,
) -> None:
    """Remember that a source file has been ingested."""
    stat = path.stat()
    conn.execute(
        "INSERT INTO source_files (path, kind, sha256, size_bytes, modified_at, processed_at) "
        "VALUES (?, ?, ?, ?, ?, ?) "
        "ON CONFLICT (path) DO UPDATE SET kind = excluded.kind, sha256 = excluded.sha256, "
        "size_bytes = excluded.size_bytes, modified_at = excluded.modified_at, "
        "processed_at = excluded.processed_at",
        (
            str(path.resolve()),
            kind,
            sha256_file(path),
            stat.st_size,
            stat.st_mtime,
            processed_at,
        ),
    )


def source_changed(conn: sqlite3.Connection, path: Path) -> bool:
    """True when the file is new or its content differs from what we ingested."""
    row = conn.execute(
        "SELECT sha256 FROM source_files WHERE path = ?", (str(path.resolve()),)
    ).fetchone()
    if row is None:
        return True
    return row["sha256"] != sha256_file(path)
