#!/usr/bin/env python3
"""Install the invoice-reconciliation skill into any agent that reads skills.

One command, every agent, every dependency:

    python scripts/install_skill.py --agent claude-code
    python scripts/install_skill.py --agent codex --scope project
    python scripts/install_skill.py --agent all
    python scripts/install_skill.py --dir ~/somewhere/skills

What it does, in order:

1. Creates a virtual environment for the pipeline (default ``.venv`` in the
   project folder) and installs ``requirements.txt`` into it.
2. Vendors the companion ``hours_calculator`` module if it can find one, so
   the hours are the review dashboard's own numbers.  Without it the built-in
   reader does the same job.
3. Copies the skill into each target agent's skills directory, with the
   ``SKILL.md`` rewritten so that every command it contains works from any
   working directory.
4. Verifies the installation by running the pipeline.

The script uses only the standard library, so it runs on a bare Python 3.8+
before any dependency is installed -- which is the point: the installer is
the first thing you need, and it must not need anything.
"""

from __future__ import annotations

import argparse
import json
import os
import platform
import shutil
import subprocess
import sys
import time
from pathlib import Path

SKILL_NAME = "invoice-reconciliation"
SKILL_DIR = Path(__file__).resolve().parent.parent

#: Code and documentation only. Data remains in the external project root.
BUNDLE_ITEMS = ("SKILL.md", "README.md", "requirements.txt", "pdf_md.py",
                "invoicing", "scripts")

#: Never copied: build artefacts and machine-specific leftovers.
EXCLUDE_NAMES = ("__pycache__", ".venv", ".pytest_cache", ".mypy_cache")
EXCLUDE_SUFFIXES = (".pyc", ".pyo", ".pyd", ".Zone.Identifier")

#: Where each agent looks for skills, per scope.
AGENT_DIRS = {
    "codex": {
        "global": ["~/.agents/skills"],
        "project": [".agents/skills"],
    },
    "claude-code": {
        "global": ["~/.claude/skills"],
        "project": [".claude/skills"],
    },
    "cursor": {
        "global": ["~/.cursor/skills"],
        "project": [".cursor/skills"],
    },
    "gemini": {
        "global": ["~/.agents/skills"],
        "project": [".agents/skills"],
    },
    "opencode": {
        "global": ["~/.agents/skills"],
        "project": [".agents/skills"],
    },
    "windsurf": {
        "global": ["~/.agents/skills"],
        "project": [".agents/skills"],
    },
    "amp": {
        "global": ["~/.agents/skills"],
        "project": [".agents/skills"],
    },
    "kiro": {
        "global": ["~/.kiro/skills"],
        "project": [".kiro/skills"],
    },
    "agents": {
        "global": ["~/.agents/skills"],
        "project": [".agents/skills"],
    },
}

AGENT_ALIASES = {
    "claude": "claude-code",
    "claudecode": "claude-code",
    "codex-cli": "codex",
    "openai-codex": "codex",
    "gemini-cli": "gemini",
    "universal": "agents",
}

#: Older Codex releases read this tree; newer ones read ``~/.agents/skills``.
CODEX_LEGACY_DIR = "~/.codex/skills"


# --------------------------------------------------------------------------
# small helpers
# --------------------------------------------------------------------------

def say(message: str = "") -> None:
    print(message, flush=True)


def ok(message: str) -> None:
    print(f"  [ok]   {message}", flush=True)


def warn(message: str) -> None:
    print(f"  [warn] {message}", flush=True)


def fail(message: str) -> None:
    print(f"  [fail] {message}", flush=True)


def venv_python(venv_dir: Path) -> Path:
    """Return the interpreter path inside a virtual environment."""
    if platform.system() == "Windows":
        return venv_dir / "Scripts" / "python.exe"
    return venv_dir / "bin" / "python"


def _ignore(directory: str, names: list) -> set:
    skip = set()
    for name in names:
        if name in EXCLUDE_NAMES or name.endswith(EXCLUDE_SUFFIXES):
            skip.add(name)
    return skip


def copy_item(source: Path, target: Path) -> None:
    """Copy a file or directory, skipping build artefacts."""
    if source.is_dir():
        shutil.copytree(source, target, dirs_exist_ok=True,
                        ignore=lambda d, names: _ignore(d, names))
    else:
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, target)


def run(command: list, cwd: Path = None, env: dict = None) -> subprocess.CompletedProcess:
    return subprocess.run(
        command, cwd=str(cwd) if cwd else None, env=env,
        capture_output=True, text=True,
    )


# --------------------------------------------------------------------------
# the virtual environment and its dependencies
# --------------------------------------------------------------------------

def ensure_venv(venv_dir: Path, python: str, dry_run: bool) -> Path:
    """Create the virtual environment if it is not there yet."""
    interpreter = venv_python(venv_dir)
    if interpreter.is_file():
        ok(f"virtual environment ready: {venv_dir}")
        return interpreter
    if dry_run:
        say(f"  [dry-run] would create {venv_dir}")
        return interpreter
    say(f"creating virtual environment: {venv_dir}")
    result = run([python, "-m", "venv", str(venv_dir)])
    if result.returncode != 0 or not interpreter.is_file():
        # Some distributions ship Python without ensurepip.
        retry = run([python, "-m", "venv", "--without-pip", str(venv_dir)])
        if retry.returncode == 0 and interpreter.is_file():
            warn("venv created without pip; install the dependencies manually")
            return interpreter
        fail(f"could not create the virtual environment: {result.stderr.strip()}")
        raise SystemExit(1)
    ok(f"virtual environment ready: {venv_dir}")
    return interpreter


def install_dependencies(interpreter: Path, requirements: Path, args) -> bool:
    """Install the pipeline's third-party libraries into the venv."""
    if args.skip_deps:
        warn("skipping dependency installation (--skip-deps)")
        return True
    if args.dry_run:
        say(f"  [dry-run] would run: {interpreter} -m pip install -r {requirements}")
        return True

    pip_command = [str(interpreter), "-m", "pip", "install", "-r", str(requirements)]
    if args.index_url:
        pip_command += ["--index-url", args.index_url]
    if args.pip_args:
        pip_command += args.pip_args.split()

    say("installing dependencies (this can take a minute)")
    result = run(pip_command)
    if result.returncode != 0:
        tail = (result.stderr or result.stdout or "").strip().splitlines()[-6:]
        fail("dependency installation failed:")
        for line in tail:
            say(f"         {line}")
        say("         retry with an explicit index, e.g. --index-url https://pypi.org/simple/")
        return False
    ok("dependencies installed")
    return True


def find_hours_calculator(explicit: str = None):
    """Locate the companion ``hours_calculator`` module, if it exists.

    The review dashboard's own hours checks live in a sibling project.  The
    pipeline can run without it -- the verdict still comes from the master
    timesheet -- but the duplicate-day warnings need it.

    Returns the path, or ``None`` when it cannot be found.
    """
    if explicit:
        candidate = Path(explicit).expanduser()
        if candidate.is_dir():
            candidate = candidate / "hours_calculator.py"
        return candidate if candidate.is_file() else None

    search = [
        SKILL_DIR.parent / "invoicing_automation" / "hours_calculator.py",
        SKILL_DIR / "vendor" / "hours_calculator.py",
        SKILL_DIR.parent / "pdf-to-markdown" / "hours_calculator.py",
    ]
    for candidate in search:
        if candidate.is_file():
            return candidate
    for directory in os.environ.get("PYTHONPATH", "").split(os.pathsep):
        if not directory:
            continue
        candidate = Path(directory).expanduser() / "hours_calculator.py"
        if candidate.is_file():
            return candidate
    return None


# --------------------------------------------------------------------------
# targets
# --------------------------------------------------------------------------

def resolve_agents(names: list) -> list:
    """Turn the ``--agent`` values into canonical agent names."""
    resolved = []
    for raw in names:
        for part in str(raw).replace(";", ",").split(","):
            part = part.strip().lower()
            if not part:
                continue
            part = AGENT_ALIASES.get(part, part)
            if part == "all":
                resolved.extend(AGENT_DIRS.keys())
            elif part in AGENT_DIRS:
                resolved.append(part)
            else:
                raise SystemExit(
                    f"unknown agent {part!r}. Known agents: "
                    + ", ".join(sorted(AGENT_DIRS))
                    + ", all"
                )
    seen = []
    for name in resolved:
        if name not in seen:
            seen.append(name)
    return seen


def target_dirs(agent: str, scope: str, base: Path) -> list:
    """Return the directories to install into for one agent and scope."""
    dirs = []
    for raw in AGENT_DIRS.get(agent, {}).get(scope, []):
        path = Path(raw).expanduser()
        if not path.is_absolute():
            path = (base / path).resolve()
        dirs.append(path)
    # Older Codex releases read ~/.codex/skills; if that tree exists, the
    # skill has to be there too or Codex will not see it.
    if agent == "codex" and scope == "global":
        legacy = Path(CODEX_LEGACY_DIR).expanduser()
        if legacy.is_dir() and legacy not in dirs:
            dirs.append(legacy)
    return dirs


# --------------------------------------------------------------------------
# the skill file that goes into the agent's directory
# --------------------------------------------------------------------------

def installation_section(agent: str, skill_path: Path, project_root: Path,
                         interpreter: Path, venv_dir: Path,
                         hours_calculator: Path) -> str:
    """Build the '## This installation' section appended to SKILL.md."""
    if agent == "claude-code":
        skill_ref = "${CLAUDE_SKILL_DIR}"
        fallback = (f"If `{skill_ref}` is not substituted, use the skill folder "
                    f"path above.")
    else:
        skill_ref = "<this skill folder>"
        fallback = "Replace `<this skill folder>` with the directory containing this SKILL.md."

    python = str(interpreter)
    lines = [
        "",
        "## This installation",
        "",
        f"This copy of the skill was installed for **{agent}**.",
        "",
        "| What | Where |",
        "| --- | --- |",
        "| Skill folder | The directory containing this SKILL.md |",
        f"| External data root | `{project_root}` |",
        f"| Python environment | `{venv_dir}` |",
        f"| Interpreter | `{python}` |",
    ]
    if hours_calculator:
        lines.append(f"| Companion hours module | `{hours_calculator}` |")
    lines += [
        "",
        "Run every command through the wrapper. It pins data paths to the "
        "external root. If that root moves, set `INVOICING_PROJECT_ROOT` to "
        "its new location before running the wrapper:",
        "",
        "```bash",
        f'"{python}" "{skill_ref}/scripts/run_pipeline.py" reconcile \\',
        '    "invoices/Edge Centric_Chaitanya Motupalli_1001-103126.pdf"',
        f'"{python}" "{skill_ref}/scripts/run_pipeline.py" reconcile-all',
        f'"{python}" "{skill_ref}/scripts/run_pipeline.py" ingest',
        '```',
        "",
        "Read the brief that `reconcile` prints. It is the verdict, the three "
        "numbers behind it, the reasons and the warnings.",
    ]
    if fallback:
        lines.append("")
        lines.append(fallback)
    if not hours_calculator:
        lines += [
            "",
            "> The companion `hours_calculator` module (the review "
            "dashboard's own hours logic) is **not** installed. The built-in "
            "reader is used instead: same records, same duplicate-day and "
            "missing-day checks, same verdict. Install the companion with "
            "`python scripts/install_skill.py --hours-calculator /path/to/hours_calculator.py` "
            "to make the numbers identical to the dashboard's by "
            "construction.",
        ]
    return "\n".join(lines) + "\n"


def write_skill_md(dest: Path, agent: str, project_root: Path,
                   interpreter: Path, venv_dir: Path,
                   hours_calculator: Path) -> None:
    source = (SKILL_DIR / "SKILL.md").read_text(encoding="utf-8")
    marker = "\n## This installation\n"
    if marker in source:
        source = source.split(marker)[0].rstrip() + "\n"
    section = installation_section(
        agent, dest, project_root, interpreter, venv_dir, hours_calculator
    )
    (dest / "SKILL.md").write_text(source.rstrip() + "\n" + section,
                                   encoding="utf-8")


def write_launchers(dest: Path, interpreter: Path) -> None:
    """Write tiny launchers so the skill can be run without typing a path."""
    scripts_dir = dest / "scripts"
    run_sh = scripts_dir / "run"
    run_sh.write_text(
        "#!/usr/bin/env bash\n"
        'script_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"\n'
        'exec python3 "$script_dir/run_pipeline.py" "$@"\n',
        encoding="utf-8",
    )
    try:
        run_sh.chmod(0o755)
    except OSError:
        pass
    (scripts_dir / "run.cmd").write_text(
        "@echo off\r\n"
        'py -3 "%~dp0run_pipeline.py" %*\r\n',
        encoding="utf-8",
    )


def write_install_json(dest: Path, agent: str, project_root: Path,
                       interpreter: Path, venv_dir: Path,
                       hours_calculator: Path, no_bundle: bool = False) -> None:
    payload = {
        "skill": SKILL_NAME,
        "agent": agent,
        "code_root": str(SKILL_DIR) if no_bundle else ".",
        "project_root": str(project_root),
        "venv_dir": str(venv_dir),
        "python": str(interpreter),
        "hours_calculator": str(hours_calculator) if hours_calculator else "",
        "installed_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
    }
    (dest / "install.json").write_text(
        json.dumps(payload, indent=2) + "\n", encoding="utf-8"
    )


# --------------------------------------------------------------------------
# commands
# --------------------------------------------------------------------------

def cmd_install(args) -> int:
    project_root = Path(args.project_root).expanduser().resolve() \
        if args.project_root else SKILL_DIR
    base = Path(args.base).expanduser().resolve() if args.base else Path.cwd()
    venv_dir = Path(args.venv).expanduser().resolve() if args.venv \
        else SKILL_DIR / ".venv"
    requirements = SKILL_DIR / "requirements.txt"

    say(f"invoice-reconciliation installer")
    say(f"  project : {project_root}")

    # 1. the environment and its libraries
    interpreter = ensure_venv(venv_dir, args.python, args.dry_run)
    if not install_dependencies(interpreter, requirements, args):
        return 1

    # 2. the companion module
    hours_calculator = find_hours_calculator(args.hours_calculator)
    if args.hours_calculator and not hours_calculator:
        fail(f"no hours_calculator.py at {args.hours_calculator}")
        return 1
    if hours_calculator:
        ok(f"companion hours module found: {hours_calculator}")
    else:
        warn("companion 'hours_calculator' module not found -- the built-in "
             "reader will be used, which produces the same records and the "
             "same checks")

    # 3. the targets
    if args.dir:
        targets = [(Path(d).expanduser().resolve(), "custom")
                   for d in args.dir]
    else:
        agents = resolve_agents(args.agent or ["codex"])
        targets = []
        for agent in agents:
            for scope in args.scope:
                for directory in target_dirs(agent, scope, base):
                    targets.append((directory, agent))
        # Several agents share one directory; keep one entry per directory and
        # name all of them, so the installed skill says where it came from.
        merged = []
        for directory, agent in targets:
            for entry in merged:
                if entry[0] == directory:
                    if agent not in entry[1]:
                        entry[1] = f"{entry[1]}, {agent}"
                    break
            else:
                merged.append([directory, agent])
        targets = [(directory, label) for directory, label in merged]

    installed = []
    for directory, agent in targets:
        dest = directory / SKILL_NAME
        if dest.exists() and not args.force:
            warn(f"{dest} already exists -- use --force to replace it")
            continue
        if args.dry_run:
            say(f"  [dry-run] would install into {dest}")
            continue
        if dest.exists():
            shutil.rmtree(dest)
        dest.mkdir(parents=True, exist_ok=True)

        if not args.no_bundle:
            for item in BUNDLE_ITEMS:
                source = SKILL_DIR / item
                if source.exists():
                    copy_item(source, dest / item)
        else:
            for item in ("SKILL.md", "README.md", "requirements.txt"):
                source = SKILL_DIR / item
                if source.exists():
                    copy_item(source, dest / item)
            copy_item(SKILL_DIR / "scripts" / "run_pipeline.py",
                      dest / "scripts" / "run_pipeline.py")

        # the companion module travels with the skill
        if hours_calculator:
            copy_item(hours_calculator, dest / "vendor" / "hours_calculator.py")

        write_skill_md(dest, agent, project_root, interpreter, venv_dir,
                       hours_calculator)
        write_launchers(dest, interpreter)
        write_install_json(dest, agent, project_root, interpreter, venv_dir,
                           hours_calculator, args.no_bundle)
        installed.append((agent, dest))
        ok(f"installed for {agent} in {dest}")

    if not installed:
        return 1

    # 4. verification
    say("")
    say("verifying")
    for agent, dest in installed:
        result = verify_install(dest, project_root, interpreter)
        if result != 0:
            return result
    return 0


def verify_install(dest: Path, project_root: Path, interpreter: Path) -> int:
    """Run the pipeline from the installed copy and check that it answers."""
    runner = dest / "scripts" / "run_pipeline.py"
    if not runner.is_file():
        fail(f"{dest}: the runner is missing")
        return 1
    env = dict(os.environ)
    env["PYTHONPATH"] = str(dest)
    result = run([str(interpreter), str(runner), "status"], cwd=dest,
                 env=env)
    if result.returncode != 0:
        fail(f"{dest}: the pipeline did not start")
        for line in (result.stderr or "").strip().splitlines()[-8:]:
            say(f"         {line}")
        return 1
    try:
        status = json.loads(result.stdout)
    except ValueError:
        fail(f"{dest}: status did not return JSON")
        return 1
    if Path(status.get("database", "")).resolve() != (project_root / "data" / "invoicing.db").resolve():
        fail(f"{dest}: status read the wrong database")
        return 1
    ok(f"{dest}: the pipeline starts and uses the external data root")
    return 0


def cmd_verify(args) -> int:
    """Check an installation (or the project itself) without changing it."""
    project_root = Path(args.project_root).expanduser().resolve() \
        if args.project_root else SKILL_DIR
    interpreter = None
    for candidate in (project_root / ".venv" / "bin" / "python",
                      project_root / ".venv" / "Scripts" / "python.exe"):
        if candidate.is_file():
            interpreter = candidate
            break
    if interpreter is None:
        interpreter = Path(sys.executable)

    say("checking the project")
    say(f"  project   : {project_root}")
    say(f"  interpreter: {interpreter}")

    requirements = project_root / "requirements.txt"
    probe = run([str(interpreter), "-c",
                 "import pymupdf, openpyxl, pydantic; print('deps ok')"])
    if probe.returncode != 0:
        fail("the third-party libraries are not installed")
        say("         run: pip install -r requirements.txt")
    else:
        ok("pymupdf, openpyxl and pydantic are installed")

    hours_calculator = find_hours_calculator()
    if hours_calculator:
        ok(f"companion hours module: {hours_calculator}")
    else:
        warn("companion 'hours_calculator' module not found -- the built-in "
             "reader is used, which produces the same records and checks")

    db = project_root / "data" / "invoicing.db"
    if db.is_file():
        ok(f"reference database: {db} ({db.stat().st_size // 1024} kB)")
    else:
        fail(f"no reference database at {db} -- run 'ingest' to build it")

    invoices = sorted((project_root / "invoices").glob("*.pdf"))
    if invoices:
        ok(f"{len(invoices)} invoice(s) in {project_root / 'invoices'}")
    else:
        warn("no invoices in the invoices folder")

    # a real reconciliation, if there is something to reconcile
    runner = project_root / "scripts" / "run_pipeline.py"
    if invoices and runner.is_file():
        result = run([str(interpreter), str(runner), "reconcile",
                      str(invoices[0])], cwd=project_root)
        if result.returncode != 0:
            fail("the reconciliation did not complete")
            for line in (result.stderr or "").strip().splitlines()[-8:]:
                say(f"         {line}")
            return 1
        try:
            brief = json.loads(result.stdout)
        except ValueError:
            brief = {}
        ok(f"reconciled {invoices[0].name}: {brief.get('status', '?')}")
        for warning in brief.get("warnings", []) or []:
            say(f"         warning: {warning}")
    return 0


def cmd_uninstall(args) -> int:
    removed = 0
    if args.dir:
        dirs = [Path(d).expanduser().resolve() / SKILL_NAME for d in args.dir]
    else:
        agents = resolve_agents(args.agent or ["codex"])
        base = Path.cwd()
        dirs = []
        for agent in agents:
            for scope in args.scope:
                dirs.extend(
                    Path(d) / SKILL_NAME
                    for d in target_dirs(agent, scope, base)
                )
    for dest in dirs:
        if dest.is_dir():
            shutil.rmtree(dest)
            ok(f"removed {dest}")
            removed += 1
        else:
            say(f"  [skip] {dest} does not exist")
    if not removed:
        say("nothing to remove")
    return 0


def cmd_agents(args) -> int:
    say("known agents and where they read skills from:")
    for agent in sorted(AGENT_DIRS):
        scopes = AGENT_DIRS[agent]
        say(f"  {agent:<12} global: {', '.join(scopes['global'])}")
        say(f"  {'':<12} project: {', '.join(scopes['project'])}")
    say("")
    say("Several agents share ~/.agents/skills (codex, gemini, opencode, "
        "windsurf, amp);")
    say("installing for one of them installs for all of them.")
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="install_skill.py",
        description="Install the invoice-reconciliation skill into any agent.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    parser.add_argument("--version", action="version", version="2.0")
    sub = parser.add_subparsers(dest="command")

    def common(p):
        p.add_argument("--agent", action="append", default=[],
                       help="agent to install for (repeatable). One of: "
                            + ", ".join(sorted(AGENT_DIRS))
                            + ", all. Default: codex")
        p.add_argument("--scope", action="append", default=[],
                       choices=["global", "project"],
                       help="where to install (repeatable). Default: global")
        p.add_argument("--dir", action="append", default=[],
                       help="install into this exact skills directory "
                            "(repeatable); skips the agent table")
        p.add_argument("--force", action="store_true",
                       help="replace an existing installation")

    install = sub.add_parser("install", help="install the skill")
    common(install)
    install.add_argument("--project-root", default="",
                         help="the project folder that holds the data "
                              "(default: the folder this script is in)")
    install.add_argument("--venv", default="",
                         help="where the virtual environment lives "
                              "(default: <project>/.venv)")
    install.add_argument("--python", default=sys.executable,
                         help="interpreter used to create the virtual "
                              "environment (default: this one)")
    install.add_argument("--skip-deps", action="store_true",
                         help="do not install the third-party libraries")
    install.add_argument("--index-url", default="",
                         help="pip index URL for the dependency install")
    install.add_argument("--pip-args", default="",
                         help="extra arguments for pip")
    install.add_argument("--hours-calculator", default="",
                         help="path to the companion hours_calculator.py")
    install.add_argument("--no-bundle", action="store_true",
                         help="install only the skill file and the runner, "
                              "and use the project folder for the code")
    install.add_argument("--base", default="",
                         help="the folder that project-scoped paths are "
                              "relative to (default: the current folder)")
    install.add_argument("--dry-run", action="store_true")
    install.set_defaults(func=cmd_install)

    verify = sub.add_parser("verify", help="check the installation")
    verify.add_argument("--project-root", default="",
                        help="the project folder to check")
    verify.set_defaults(func=cmd_verify)

    uninstall = sub.add_parser("uninstall", help="remove the skill")
    common(uninstall)
    uninstall.set_defaults(func=cmd_uninstall)

    agents = sub.add_parser("agents", help="list the known agents")
    agents.set_defaults(func=cmd_agents)
    return parser


def main(argv=None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    if not getattr(args, "command", None):
        args = parser.parse_args(["install", *(argv or [])])
    if getattr(args, "scope", None) == []:
        args.scope = ["global"]
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())
