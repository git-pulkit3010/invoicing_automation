## Invoice

11 Chadd Court

Parsippany-Troy Hills, NJ 07054

(973) 515-5311

# Edge Centric, LLC

| Bill to | CompNova, LLC | Invoice | 1290 |
| --- | --- | --- | --- |
|  | invoice@compnova.net | **Date** | Nov 12, 2026 |

- **Terms:** Net 45
- **Due date:** Dec 19, 2026
- **Amount due:** $15,200.00

| Items | Quantity | Price | Amount |
| --- | --- | --- | --- |
| Chaitanya Motupalli | 152 | $100.00 | $15,200.00 |

Services for Oct 2026

- **Subtotal:** $15,200.00
- **Total:** $15,200.00
- **Paid:** $0.00

## Amount due $15,200.00

**Use this link to pay online:** https://app02.us.bill.com/p/edgecentricllc
