# Invoice

| Simple CTI Solutions, LLC | Date: | November 1, 2026 |
| --- | --- | --- |
| 75 Dawson Ave, Boonton, NJ 07005 | Invoice #: | Comp2026-11VB |

- **Customer ID:** Compnova
- **To:** Compnova

|   | Consultatant Name Job Payment Terms |   | Due Date |
| --- | --- | --- | --- |
| Vaibhav Bansal |  |  |  |
| 10/01/2026 - 10/31/2026 |  |  | 12/1/26 |
| **Hours** | **Description** | **Unit Price** | **Line Total** |
| 176.00 | Consulting Vaibhav Bansal | $ 98.00 | $ 17,248.00 |
|  |  | Subtotal Sales Tax Total | $ 17,248.00 **$** **17,248.00** |

Make all checks payable to [Simple CTI Solutions, LLC]

### Thank you for your business!

[75 Dawson Ave, Boonton, NJ 07005] [973.767.8568] [Simplectisolutions@gmail.com]
