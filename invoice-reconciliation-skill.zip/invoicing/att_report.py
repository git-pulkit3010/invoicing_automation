"""A self-contained reader for the ATT time-report workbook.

The review dashboard computes worked hours in its own ``hours_calculator``
module, and the pipeline prefers that module when it is installed -- the
numbers are then identical to the dashboard's, by construction.

This module is the fallback that makes the skill installable anywhere.  It
reads the same workbook, produces the same normalised records and runs the
same two checks (duplicate days, missing weekdays) without needing the
sibling project.

The workbook is a flat table with one row per consultant per worked day:

    Period Year | Period Month | Period Week | Period Day | Week Start Date |
    Week End Date | Vendor ID | Vendor Name | Supervisor ATTUID | Segment ID |
    Segment Name | Contractor ATTUID | Contractor First Name |
    Contractor Last Name | Correcting Hours Indicator | Regular Hours by Day |
    OT Hours by Day | Period Week Regular Hours | Period Week OT Hours

The worked date is not stored: it is the period day counted from the start of
the period week.
"""

from __future__ import annotations

import datetime as dt
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional

#: The sheet the report lives on.
SHEET_NAME = "ATT Time Report"

#: Standard hours per weekday, used for the full-month benchmark.
STANDARD_DAY_HOURS = 8.0

#: Header names the reader needs, in the order it looks for them.
REQUIRED_COLUMNS = (
    "Period Year",
    "Period Month",
    "Period Week",
    "Period Day",
    "Week Start Date",
    "Week End Date",
    "Vendor Name",
    "Supervisor ATTUID",
    "Segment Name",
    "Contractor ATTUID",
    "Contractor First Name",
    "Contractor Last Name",
    "Correcting Hours Indicator",
    "Regular Hours by Day",
    "OT Hours by Day",
    "Period Week Regular Hours",
    "Period Week OT Hours",
)


@dataclass
class DayEntry:
    """One consultant on one worked day."""

    year: int = 0
    month: int = 0
    period_week: str = ""
    day: int = 0
    work_date: Optional[dt.date] = None
    week_start: Optional[dt.date] = None
    week_end: Optional[dt.date] = None
    contractor_attuid: str = ""
    first_name: str = ""
    last_name: str = ""
    supervisor_attuid: str = ""
    vendor_name: str = ""
    segment_name: str = ""
    correcting_hours: str = "N"
    regular_hours: float = 0.0
    ot_hours: float = 0.0
    week_regular_hours: float = 0.0
    week_ot_hours: float = 0.0

    @property
    def total_hours(self) -> float:
        return float(self.regular_hours or 0.0) + float(self.ot_hours or 0.0)


@dataclass
class TimeReportData:
    """Every entry in the workbook."""

    entries: List[DayEntry] = field(default_factory=list)
    source: Optional[Any] = None

    def compute(self, contractor_id: str, year: int, month: int) -> "ComputedReport":
        """Return the worked-hours report for one contractor and month."""
        return ComputedReport(
            entries=[
                entry for entry in self.entries
                if entry.contractor_attuid == contractor_id
                and entry.year == year
                and entry.month == month
            ],
            contractor_id=contractor_id,
            year=year,
            month=month,
        )


@dataclass
class ComputedReport:
    """The hours one consultant worked in one month, plus the checks."""

    entries: List[DayEntry] = field(default_factory=list)
    contractor_id: str = ""
    year: int = 0
    month: int = 0

    # -- totals -----------------------------------------------------------
    @property
    def total_hours(self) -> float:
        return sum(entry.total_hours for entry in self.entries)

    @property
    def regular_hours(self) -> float:
        return sum(float(entry.regular_hours or 0.0) for entry in self.entries)

    @property
    def ot_hours(self) -> float:
        return sum(float(entry.ot_hours or 0.0) for entry in self.entries)

    @property
    def days_recorded(self) -> int:
        return len({entry.work_date for entry in self.entries if entry.work_date})

    @property
    def benchmark_hours(self) -> float:
        return STANDARD_DAY_HOURS * len(_weekdays_in_month(self.year, self.month))

    # -- checks -----------------------------------------------------------
    def audits(self) -> List[Dict[str, str]]:
        """The two checks the dashboard applies: duplicate and missing days."""
        notes: List[Dict[str, str]] = []

        seen: Dict[dt.date, int] = {}
        for entry in self.entries:
            if entry.work_date:
                seen[entry.work_date] = seen.get(entry.work_date, 0) + 1
        duplicates = sorted(date for date, count in seen.items() if count > 1)
        if duplicates:
            listed = ", ".join(date.isoformat() for date in duplicates)
            notes.append({
                "check": "Duplicate days",
                "finding": (
                    f"{len(duplicates)} day(s) appear more than once in the "
                    f"timesheet ({listed}); the hours are counted once per row."
                ),
            })

        worked = {entry.work_date for entry in self.entries if entry.work_date}
        missing = [
            date for date in _weekdays_in_month(self.year, self.month)
            if date not in worked
        ]
        if missing:
            listed = ", ".join(date.isoformat() for date in missing)
            notes.append({
                "check": "Missing weekdays",
                "finding": (
                    f"{len(missing)} weekday(s) in the period have no entry "
                    f"({listed})."
                ),
            })
        return notes

    def as_dict(self) -> Dict[str, Any]:
        """The shape the reconciliation engine and the report expect."""
        return {
            "contractor_id": self.contractor_id,
            "period": f"{self.year:04d}-{self.month:02d}",
            "summary": {
                "total_hours": round(self.total_hours, 2),
                "regular_hours": round(self.regular_hours, 2),
                "ot_hours": round(self.ot_hours, 2),
                "days_recorded": self.days_recorded,
                "benchmark_hours": round(self.benchmark_hours, 2),
            },
            "audits": self.audits(),
        }


def _weekdays_in_month(year: int, month: int) -> List[dt.date]:
    """Every Monday-to-Friday date in the month."""
    if not year or not month:
        return []
    days: List[dt.date] = []
    date = dt.date(year, month, 1)
    while date.month == month:
        if date.weekday() < 5:
            days.append(date)
        date += dt.timedelta(days=1)
    return days


def _as_int(value: Any, default: int = 0) -> int:
    try:
        return int(float(value))
    except (TypeError, ValueError):
        return default


def _as_float(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def _as_date(value: Any) -> Optional[dt.date]:
    if value is None:
        return None
    if isinstance(value, dt.datetime):
        return value.date()
    if isinstance(value, dt.date):
        return value
    text = str(value).strip()
    for pattern in ("%Y-%m-%d", "%m/%d/%Y", "%m/%d/%y"):
        try:
            return dt.datetime.strptime(text, pattern).date()
        except ValueError:
            continue
    return None


def find_header_row(sheet) -> Optional[tuple]:
    """Return ``(row_number, {column name: index})`` for the header row."""
    wanted = {column.lower() for column in REQUIRED_COLUMNS}
    for row in range(1, min(sheet.max_row, 25) + 1):
        index: Dict[str, int] = {}
        for column in range(1, sheet.max_column + 1):
            value = sheet.cell(row, column).value
            if value is None:
                continue
            text = str(value).strip()
            if text and text not in index:
                index[text] = column
        if wanted.issubset({name.lower() for name in index}):
            return row, index
    return None


def load_report(path: Path) -> TimeReportData:
    """Read the master timesheet workbook into normalised entries."""
    import openpyxl

    workbook = openpyxl.load_workbook(path, data_only=True)
    try:
        sheet = (workbook[SHEET_NAME] if SHEET_NAME in workbook.sheetnames
                 else workbook[workbook.sheetnames[0]])
        found = find_header_row(sheet)
        if not found:
            raise ValueError(
                f"{Path(path).name}: no header row with the expected columns"
            )
        header_row, index = found

        def cell(row: int, name: str) -> Any:
            column = index.get(name)
            if column is None:
                column = next(
                    (c for n, c in index.items() if n.lower() == name.lower()), None
                )
            if column is None:
                return None
            return sheet.cell(row, column).value

        entries: List[DayEntry] = []
        for row in range(header_row + 1, sheet.max_row + 1):
            attuid = cell(row, "Contractor ATTUID")
            attuid = "" if attuid is None else str(attuid).strip()
            year = _as_int(cell(row, "Period Year"))
            month = _as_int(cell(row, "Period Month"))
            if not attuid or not year or not month:
                continue
            week_start = _as_date(cell(row, "Week Start Date"))
            week_end = _as_date(cell(row, "Week End Date"))
            day = _as_int(cell(row, "Period Day"))
            # The period day is the calendar day of the month the hours were
            # worked; the week columns say which week that day falls in.
            work_date = None
            if day:
                try:
                    work_date = dt.date(year, month, day)
                except ValueError:
                    work_date = None
            if work_date is None and week_start and day:
                work_date = week_start + dt.timedelta(days=day - 1)
            entries.append(DayEntry(
                year=year,
                month=month,
                period_week=str(cell(row, "Period Week") or ""),
                day=day,
                work_date=work_date,
                week_start=week_start,
                week_end=week_end,
                contractor_attuid=attuid,
                first_name=str(cell(row, "Contractor First Name") or "").strip(),
                last_name=str(cell(row, "Contractor Last Name") or "").strip(),
                supervisor_attuid=str(cell(row, "Supervisor ATTUID") or "").strip(),
                vendor_name=str(cell(row, "Vendor Name") or "").strip(),
                segment_name=str(cell(row, "Segment Name") or "").strip(),
                correcting_hours=str(
                    cell(row, "Correcting Hours Indicator") or "N").strip() or "N",
                regular_hours=_as_float(cell(row, "Regular Hours by Day")),
                ot_hours=_as_float(cell(row, "OT Hours by Day")),
                week_regular_hours=_as_float(cell(row, "Period Week Regular Hours")),
                week_ot_hours=_as_float(cell(row, "Period Week OT Hours")),
            ))
    finally:
        workbook.close()
    return TimeReportData(entries=entries, source=Path(path))


def find_workbook(base_dir: Path, explicit: Optional[Path] = None) -> Optional[Path]:
    """Locate the master timesheet workbook."""
    if explicit:
        candidate = Path(explicit)
        return candidate if candidate.is_file() else None
    base = Path(base_dir)
    for pattern in ("*.xlsx", "*CMPM*.xlsx", "*Report*.xlsx"):
        matches = sorted(base.glob(pattern))
        if matches:
            return matches[0]
    return None


def entry_from_row(row: Dict[str, Any]) -> DayEntry:
    """Build an entry from a normalised database row."""
    def as_date(value: Any) -> Optional[dt.date]:
        if not value:
            return None
        if isinstance(value, dt.datetime):
            return value.date()
        if isinstance(value, dt.date):
            return value
        try:
            return dt.date.fromisoformat(str(value))
        except ValueError:
            return None

    regular = _as_float(row.get("regular_hours"))
    overtime = _as_float(row.get("ot_hours"))
    return DayEntry(
        year=_as_int(row.get("period_year")),
        month=_as_int(row.get("period_month")),
        period_week=str(row.get("period_week") or ""),
        day=(as_date(row.get("work_date")).day if as_date(row.get("work_date")) else 0),
        work_date=as_date(row.get("work_date")),
        week_start=as_date(row.get("week_start")),
        week_end=as_date(row.get("week_end")),
        contractor_attuid=str(row.get("contractor_id") or ""),
        first_name=str(row.get("first_name") or row.get("c_first") or ""),
        last_name=str(row.get("last_name") or row.get("c_last") or ""),
        supervisor_attuid=str(row.get("supervisor_attuid") or ""),
        vendor_name=str(row.get("vendor_name") or row.get("c_vendor") or ""),
        segment_name=str(row.get("segment_name") or ""),
        correcting_hours=str(row.get("correcting_flag") or "N"),
        regular_hours=regular,
        ot_hours=overtime,
        week_regular_hours=_as_float(row.get("week_regular_hours")),
        week_ot_hours=_as_float(row.get("week_ot_hours")),
    )
