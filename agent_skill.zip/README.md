# Invoice reconciliation skill

A hybrid **agentic + deterministic** system for checking vendor invoices
against the CompNova master timesheet and the signed vendor work orders.

The agent orchestrates and explains. Python does the data processing,
matching, calculation and verification. That split is what makes the system
fast, cheap, repeatable and auditable: a folder of dozens of invoices costs
one agent pass, not dozens, and every verdict can be traced back to a source
row.

## Layout

```
agentic_skill/
├── SKILL.md                     the agent-facing skill
├── invoicing/                   the deterministic core
│   ├── config.py                paths and tunables
│   ├── textutil.py              PDF geometry, value parsing, Markdown helpers
│   ├── extract.py               PDF -> validated structured fields
│   ├── markdown.py              PDF -> Markdown, and the second reading
│   ├── models.py                pydantic schemas
│   ├── db.py                    SQLite schema
│   ├── ingest.py                Excel + work orders -> SQLite
│   ├── reconcile.py             the reconciliation engine
│   ├── report.py                brief + JSON + Markdown rendering
│   ├── hours_source.py          bridge to the sibling hours calculator
│   └── cli.py                   command line entry points
├── scripts/                     thin wrappers the agent calls
├── tests/                       unit and end-to-end tests
├── data/invoicing.db            normalised reference records
└── output/                      one brief, report, JSON and Markdown per invoice
```

## Setup

```bash
python3 -m venv .venv
.venv/bin/pip install -r requirements.txt
```

The worked-hours logic is not reimplemented here: it is imported from the
sibling Flask project (`../invoicing_automation/hours_calculator.py`), so the
numbers the agent sees are exactly the ones the review dashboard shows.

## Running it

```bash
# 1. Load the reference data (run this when the Excel or a work order changes)
.venv/bin/python scripts/ingest_references.py

# 2. Reconcile one invoice -- prints the brief, writes every artefact
.venv/bin/python scripts/reconcile_invoice.py "invoices/Edge Centric_Chaitanya Motupalli_1001-103126.pdf"

# 3. Or reconcile the whole folder in one pass
.venv/bin/python -m invoicing.cli reconcile-all

# 4. Read a document as Markdown (the agent never needs a PDF reader)
.venv/bin/python -m invoicing.cli source-markdown "invoices/....pdf"

# 5. Or watch for new invoices
.venv/bin/python scripts/watch_invoices.py
```

Every command prints **one** JSON document on stdout, so the output can be
piped straight into `jq`.

## Installing the skill

The skill lives in `SKILL.md`. To make it available to Codex (and to any
other agent that reads `~/.codex/skills`):

```bash
./scripts/install_skill.sh            # install into $CODEX_HOME/skills
./scripts/install_skill.sh --force    # replace an existing installation
```

The installed copy records where the pipeline lives, so the agent knows which
folder to run the commands in. The skill is available from the next turn.

## How the extraction works

The four invoice PDFs in `invoices/` use four completely different layouts, so
the extractor does not look for a template. It works on **cells**: a printed
row split at horizontal gaps, so a label, a date and an amount are separate
things even when the producer drew them in one continuous line.

* A **column header** naming a quantity, a unit price *and* an amount
  identifies the line-item table. The cells underneath are matched to those
  columns by position.
* A **form label** (on the work orders) is read by locating the label cell
  and taking the text to its right, in the same column.
* Every number is **cross-checked against the document itself**: quantity
  times rate must equal the line amount. A check that fails downgrades the
  extraction instead of being trusted.
* The consultant's id comes from the **validated registry** built from the
  master Excel, never from a guess.
* Every page is searched, so a long invoice that puts its table or its totals
  on page two is read as well as a one-page invoice.

## Every document is read twice

This is the part that makes the agent fast without making it sloppy.

1. The **PDF geometry** -- word boxes, rows and cells -- produces the numbers.
2. The **Markdown rendering** -- blocks and tables, produced by the
   deterministic `pdf_md.py` converter -- is what the agent reads, and it is
   read back into numbers as well.

The two readings are compared by `invoicing/markdown.py`:

* When they agree, the figure is backed by two independent layout analyses.
* When they disagree, the disagreement is reported as a warning. It is never
  resolved silently, because a disagreement means one of the two readings is
  wrong and a human has to look.

Why Markdown rather than the PDF as the source of truth? Because Markdown is
what an agent can actually read: it is plain text, it costs a fraction of the
tokens of the JSON extraction, and the renderer reconstructs tables, so the
billable rows survive the conversion. But the conversion *can* lose a detail,
so it is not trusted to produce the numbers -- it is trusted to corroborate
them and to show the agent what the document says.

## How the verdict is reached

| Status | Meaning |
| --- | --- |
| `MATCH` | Hours, rate and amount all agree with the timesheet and the work order in force. |
| `MISMATCH` | The hours, the rate or the amount disagrees. `reasons` says which, and by how much. |
| `REVIEW_REQUIRED` | Something is missing or uncertain: no rate on file, an expired work order, an ambiguous contractor, an unreadable document. |

The engine never fabricates a match or a mismatch. In particular:

* Hours come from the timesheet, never from the invoice.
* The rate comes from the work order **in force during the billing period**.
  An expired work order produces `REVIEW_REQUIRED`, even when the amount
  happens to agree.
* `hours x rate` is compared against the invoice **subtotal**, not its final
  payable total, so taxes and adjustments do not create false mismatches.

## What the agent reads

For each invoice the pipeline writes four files:

| File | Size | What it is |
| --- | --- | --- |
| `output/<invoice>.brief.json` | ~0.7 kB | the verdict, the three numbers, the reasons |
| `output/<invoice>.source.md` | ~0.7 kB | the document itself, as Markdown |
| `output/<invoice>.md` | ~1.5 kB | the report a reviewer reads |
| `output/<invoice>.json` | ~9.5 kB | the full result, extraction and audit trail |

The agent reads the brief first and only opens the others when a field needs
checking. Reading the brief instead of the full JSON is a 14x reduction in
what the agent has to load per invoice.

## Speed

Measured on the four sample invoices (this machine):

| Step | Before | After |
| --- | --- | --- |
| Ingest reference data (nothing changed) | 0.87 s | 0.33 s |
| Ingest reference data (everything re-read) | 0.87 s | 0.83 s |
| Reconcile all four invoices | 0.42 s | 0.36 s |
| What the agent has to read per invoice | 9.5 kB | 0.7 kB |

The reference step is faster because unchanged files are not re-read (the
`source_files` table already tracks their hashes); the reconciliation is
faster because it is one process with one database connection and one JSON
document; and the agent is faster because it reads a brief instead of the
whole audit trail.

## Current result for the sample folder

| Invoice | Consultant | Verdict |
| --- | --- | --- |
| Edge Centric 1290 | Chaitanya Motupalli (`cx6008`) | `MATCH` — 152 h @ $100 = $15,200 |
| Indotronix 57977W | Harish Giriraju (`hg5064`) | `REVIEW_REQUIRED` — work order expired 2026-03-31 |
| Itek Info 1841 | Srilasya Samudrala (`sx4462`) | `MATCH` — 176 h @ $83 = $14,608 |
| Simple CTI Comp2026-11VB | Vaibhav Bansal (`vb771h`) | `REVIEW_REQUIRED` — no work order on file |

All four invoices bill exactly the hours the master timesheet records. The
two open items are contract gaps, not arithmetic errors.

## Tests

```bash
.venv/bin/python -m unittest discover -s tests -v
```
