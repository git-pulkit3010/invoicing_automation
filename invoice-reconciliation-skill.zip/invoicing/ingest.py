"""Reference-data ingestion: the Excel timesheet and the vendor work orders.

This is the workflow that runs only when the source files change.  Keeping
it separate from invoice reconciliation is the single biggest performance
win in the architecture: the master Excel is parsed once, not once per
invoice.
"""

from __future__ import annotations

import datetime as dt
import sqlite3
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import openpyxl

from .config import EXCEL_PATH, WORK_ORDERS_DIR
from .db import record_source, sha256_file, source_changed
from .extract import extract_work_order
from .hours_source import load_report
from .models import ContractorRef
from .textutil import norm_name

SHEET_NAME = "ATT Time Report"
REQUIRED_COLUMNS = (
    "Period Year", "Period Month", "Period Day", "Contractor ATTUID",
    "Contractor First Name", "Contractor Last Name",
    "Regular Hours by Day", "OT Hours by Day",
)


@dataclass
class IngestResult:
    """What one ingestion run did."""

    source: str
    contractors: int = 0
    timesheet_rows: int = 0
    work_orders: int = 0
    #: Files that were already up to date and did not have to be re-read.
    unchanged: int = 0
    #: Work orders whose PDF is no longer in the folder.
    removed: List[str] = field(default_factory=list)
    #: True when the reference data was actually re-read.
    reloaded: bool = False
    skipped: List[str] = field(default_factory=list)

    def summary(self) -> str:
        parts = [f"{self.source}:"]
        if self.contractors:
            parts.append(f"{self.contractors} contractors")
        if self.timesheet_rows:
            parts.append(f"{self.timesheet_rows} timesheet rows")
        if self.work_orders:
            parts.append(f"{self.work_orders} work orders")
        if self.unchanged:
            parts.append(f"{self.unchanged} unchanged")
        if self.removed:
            parts.append(f"{len(self.removed)} removed")
        if self.skipped:
            parts.append(f"{len(self.skipped)} skipped")
        return " ".join(parts)


def _find_header_row(sheet) -> Optional[Tuple[int, Dict[str, int]]]:
    """Locate the header row and map each column name to its index."""
    wanted = {c.lower() for c in REQUIRED_COLUMNS}
    for row in range(1, min(sheet.max_row, 25) + 1):
        index: Dict[str, int] = {}
        for column in range(1, sheet.max_column + 1):
            value = sheet.cell(row, column).value
            if value is None:
                continue
            text = str(value).strip()
            if text and text not in index:
                index[text] = column
        if wanted.issubset({k.lower() for k in index}):
            return row, index
    return None


def _as_int(value, default: int = 0) -> int:
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def ingest_excel(
    conn: sqlite3.Connection,
    excel_path: Optional[Path] = None,
    force: bool = False,
) -> IngestResult:
    """Import the master timesheet into SQLite.

    The worked-hours logic comes from the sibling ``hours_calculator``
    module, so the numbers here are exactly the ones the review dashboard
    shows.
    """
    path = Path(excel_path or EXCEL_PATH)
    result = IngestResult(source=path.name)
    if not path.is_file():
        result.skipped = [f"{path.name} not found"]
        return result

    # The workbook is parsed once, not once per invoice.  When it has not
    # changed there is nothing to do, and skipping it keeps the reference
    # step cheap enough to run before every batch of invoices.
    if not force and not source_changed(conn, path):
        result.skipped = [f"{path.name} is unchanged"]
        result.unchanged = 1
        return result

    report = load_report(path)
    workbook = openpyxl.load_workbook(path, data_only=True)
    sheet = workbook[SHEET_NAME] if SHEET_NAME in workbook.sheetnames else workbook[workbook.sheetnames[0]]
    header = _find_header_row(sheet)
    source_rows: List[Tuple[int, str]] = []
    if header:
        header_row, index = header
        attuid_col = index.get("Contractor ATTUID")
        year_col = index.get("Period Year")
        month_col = index.get("Period Month")
        for row in range(header_row + 1, sheet.max_row + 1):
            attuid = sheet.cell(row, attuid_col).value if attuid_col else None
            year = _as_int(sheet.cell(row, year_col).value) if year_col else 0
            month = _as_int(sheet.cell(row, month_col).value) if month_col else 0
            attuid = "" if attuid is None else str(attuid).strip()
            if not attuid or not year or not month:
                continue
            source_rows.append((row, attuid))
    workbook.close()

    conn.execute("DELETE FROM timesheet_entries")
    conn.execute("DELETE FROM contractors")

    contractors: Dict[str, ContractorRef] = {}
    for entry in report.entries:
        contractors.setdefault(entry.contractor_attuid, ContractorRef(
            contractor_id=entry.contractor_attuid,
            first_name=entry.first_name.title(),
            last_name=entry.last_name.title(),
            full_name=f"{entry.first_name.title()} {entry.last_name.title()}",
            vendor_name=entry.vendor_name,
        ))
    for contractor in contractors.values():
        conn.execute(
            "INSERT OR REPLACE INTO contractors "
            "(contractor_id, first_name, last_name, full_name, normalized_name, vendor_name) "
            "VALUES (?, ?, ?, ?, ?, ?)",
            (
                contractor.contractor_id,
                contractor.first_name,
                contractor.last_name,
                contractor.full_name,
                norm_name(contractor.full_name),
                contractor.vendor_name,
            ),
        )
    result.contractors = len(contractors)

    # ``report.entries`` skips exactly the rows we skipped above, so the two
    # sequences line up and every entry keeps its row number in the Excel.
    for index, entry in enumerate(report.entries):
        row_number = source_rows[index][1] if index < len(source_rows) else None
        work_date = entry.work_date
        conn.execute(
            "INSERT INTO timesheet_entries ("
            "contractor_id, work_date, period_year, period_month, period_week, "
            "week_start, week_end, regular_hours, ot_hours, total_hours, "
            "correcting_flag, first_name, last_name, supervisor_attuid, "
            "segment_name, week_regular_hours, week_ot_hours, source_file, source_row) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (
                entry.contractor_attuid,
                work_date.isoformat() if work_date else "",
                entry.year,
                entry.month,
                entry.period_week,
                entry.week_start.isoformat() if entry.week_start else None,
                entry.week_end.isoformat() if entry.week_end else None,
                entry.regular_hours,
                entry.ot_hours,
                entry.total_hours,
                entry.correcting_hours,
                entry.first_name,
                entry.last_name,
                entry.supervisor_attuid,
                entry.segment_name,
                entry.week_regular_hours,
                entry.week_ot_hours,
                path.name,
                row_number,
            ),
        )
    result.timesheet_rows = len(report.entries)
    result.reloaded = True

    record_source(conn, path, "excel", dt.datetime.now(dt.timezone.utc).isoformat())
    return result


def load_roster(conn: sqlite3.Connection) -> List[ContractorRef]:
    """Read the contractor registry out of the database."""
    roster: List[ContractorRef] = []
    for row in conn.execute(
        "SELECT contractor_id, first_name, last_name, full_name, vendor_name "
        "FROM contractors ORDER BY last_name, first_name"
    ):
        roster.append(ContractorRef(
            contractor_id=row["contractor_id"],
            first_name=row["first_name"],
            last_name=row["last_name"],
            full_name=row["full_name"],
            vendor_name=row["vendor_name"],
        ))
    return roster


def ingest_work_orders(
    conn: sqlite3.Connection,
    folder: Optional[Path] = None,
    force: bool = False,
) -> IngestResult:
    """Import every work order PDF in ``folder`` into SQLite."""
    directory = Path(folder or WORK_ORDERS_DIR)
    result = IngestResult(source=directory.name)
    if not directory.is_dir():
        result.skipped = [f"{directory} not found"]
        return result

    roster = load_roster(conn)
    present = set()
    for path in sorted(directory.glob("*.pdf")):
        if path.name.endswith(":Zone.Identifier"):
            continue
        present.add(path.name)
        if not force and not source_changed(conn, path):
            result.unchanged += 1
            continue
        extraction = extract_work_order(path)
        consultant_id = ""
        if roster:
            hits = [
                c for c in roster
                if norm_name(c.full_name) and norm_name(c.full_name) in norm_name(
                    extraction.consultant_name.value or ""
                )
            ]
            if len(hits) == 1:
                consultant_id = hits[0].contractor_id
        conn.execute(
            "INSERT OR REPLACE INTO work_orders ("
            "source_file, source_sha256, work_order_ref, vendor_name, "
            "consultant_name, consultant_id, billing_rate, rate_unit, client_name, "
            "start_date, end_date, net_days, page_count, extraction_status, "
            "extracted_json, ingested_at) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (
                path.name,
                sha256_file(path),
                extraction.work_order_ref.value,
                extraction.vendor_name.value,
                extraction.consultant_name.value,
                consultant_id,
                extraction.billing_rate.value,
                extraction.rate_unit.value,
                extraction.client_name.value,
                extraction.start_date.value,
                extraction.end_date.value,
                int(extraction.net_days.value) if extraction.net_days.value else None,
                extraction.page_count,
                extraction.extraction_status,
                extraction.model_dump_json(),
                dt.datetime.now(dt.timezone.utc).isoformat(),
            ),
        )
        result.work_orders += 1
        record_source(conn, path, "work_order", dt.datetime.now(dt.timezone.utc).isoformat())

    # A work order whose PDF has been taken away must not stay in the
    # database: it would keep supplying a rate that is no longer on file.
    for row in list(conn.execute("SELECT id, source_file FROM work_orders")):
        if row["source_file"] not in present:
            conn.execute("DELETE FROM work_orders WHERE id = ?", (row["id"],))
            result.removed.append(row["source_file"])
    return result
