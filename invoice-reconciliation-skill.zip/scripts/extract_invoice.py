#!/usr/bin/env python3
"""Read an invoice PDF into a structured, validated extraction.

Use this when you need to look at an invoice before reconciling it -- for
example to check that the consultant, the billing period and the amount were
read correctly.  The output is JSON, one object per field, each with the
evidence it came from.

    python scripts/extract_invoice.py "invoices/Some Vendor_Ann Lee_1001-103126.pdf"
"""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from invoicing.cli import main  # noqa: E402

if __name__ == "__main__":
    raise SystemExit(main(["extract-invoice", *sys.argv[1:]]))
