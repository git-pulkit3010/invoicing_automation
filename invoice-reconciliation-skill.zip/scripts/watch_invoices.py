#!/usr/bin/env python3
"""Watch the invoice folder and reconcile each invoice as it arrives.

The watcher waits for a PDF to stop growing before reading it, so a file
that is still being copied is never parsed half-written.

    python scripts/watch_invoices.py --folder invoices
"""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from invoicing.cli import main  # noqa: E402

if __name__ == "__main__":
    raise SystemExit(main(["watch", *sys.argv[1:]]))
