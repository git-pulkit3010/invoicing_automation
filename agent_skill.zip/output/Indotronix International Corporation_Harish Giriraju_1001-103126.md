# Invoice reconciliation

**Harish Giriraju — October 2026**

- Invoice file: `Indotronix International Corporation_Harish Giriraju_1001-103126.pdf`
- Invoice number: `57977W`
- Vendor: Indotronix International Corporation
- Contractor id: `hg5064`
- Status: **REVIEW REQUIRED**

## Amounts

| Item | Value |
| --- | --- |
| Verified billable hours | 160 |
| Hours on the invoice | 160 |
| Contracted hourly rate | 73.00 |
| Rate on the invoice | 73.00 |
| Expected amount | 11,680.00 |
| Invoice amount | 11,680.00 |
| Difference | +0.00 |
| Currency | USD |

## Findings

- No work order is in force for the billing period, so the billed rate cannot be confirmed against a contract.

## Warnings

- The most recent work order for this consultant (Harish Giriraju Vendor_Work_Order_CN.pdf) expired on 2026-03-31, before the billing period started.

## Work order

| Item | Value |
| --- | --- |
| File | `Harish Giriraju Vendor_Work_Order_CN.pdf` |
| Reference | C2C |
| Vendor | Indotronix International Corporation |
| Consultant | Harish Giriraju |
| Billing rate | USD 73 hourly |
| Rate unit | hourly |
| Effective from | 04/08/25 |
| Effective to | 03/31/26 |
| Covers the billing period | no |

## Timesheet

| Item | Value |
| --- | --- |
| Rows used | 20 |
| Total hours | 160 |
| Regular hours | 160 |
| Overtime hours | 0 |
| Days recorded | 20 |
| Full-month benchmark | 176 |

- Duplicate daily entries: None
- Aggregate rows: None
- Weekend hours: None
- Daily vs weekly totals: Match exactly
- Overtime: Zero
- Correcting-hours indicators: All N
- Missing weekdays: 2 of 22 weekday(s) have no entry (16 hours below the full-month benchmark)

---

Generated 2026-11-20T13:53:11+00:00 by the invoice-reconciliation engine.
