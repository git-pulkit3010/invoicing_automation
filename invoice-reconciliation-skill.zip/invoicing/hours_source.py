"""Bridge to the authoritative hours calculation.

The worked-hours logic already exists in the sibling Flask project
(``../invoicing_automation/hours_calculator.py``).  Rather than fork it, the
pipeline imports it so that the numbers the agent sees are exactly the
numbers the review dashboard shows.

That module is optional.  When it is not installed the pipeline falls back
to :mod:`invoicing.att_report`, which reads the same workbook and applies
the same two checks.  The skill therefore works on a machine that has never
heard of the sibling project, and it prefers the dashboard's own numbers
whenever they are available.
"""

from __future__ import annotations

import sys
from pathlib import Path
from typing import Any, Optional

from .config import SIBLING_APP_DIR

_MODULE_NAME = "hours_calculator"
_module: Optional[Any] = None


class HoursSourceUnavailable(RuntimeError):
    """Raised when the sibling hours calculator cannot be imported."""


def _candidate_dirs() -> list:
    dirs = [SIBLING_APP_DIR]
    # Fall back to a copy that may live inside the skill folder itself.
    local = Path(__file__).resolve().parent.parent / "vendor"
    dirs.append(local)
    return [d for d in dirs if d.is_dir()]


def hours_calculator_location() -> Optional[str]:
    """Return where the companion module was found, or ``None``.

    Used by the installer and by ``status`` so that a missing companion is
    reported as a fact rather than as a crash half-way through a
    reconciliation.
    """
    if _MODULE_NAME in sys.modules:
        module_file = getattr(sys.modules[_MODULE_NAME], "__file__", None)
        return module_file
    for directory in _candidate_dirs():
        candidate = directory / f"{_MODULE_NAME}.py"
        if candidate.is_file():
            return str(candidate)
    return None


def load_hours_calculator():
    """Import and return the sibling ``hours_calculator`` module."""
    global _module
    if _module is not None:
        return _module
    if _MODULE_NAME in sys.modules:
        _module = sys.modules[_MODULE_NAME]
        return _module
    for directory in _candidate_dirs():
        path = str(directory)
        if path not in sys.path:
            sys.path.insert(0, path)
        try:
            _module = __import__(_MODULE_NAME)
            return _module
        except ImportError:
            continue
    raise HoursSourceUnavailable(
        "Could not import 'hours_calculator'. Clone the sibling project, drop the module into "
        "the skill's vendor/ folder, or set PYTHONPATH to include it. The "
        "pipeline falls back to its built-in reader when it is absent."
    )


def load_report(path: Path):
    """Parse the ATT time-report workbook into a ``TimeReportData``.

    The companion module is used when it is installed, so that the numbers
    are the dashboard's numbers.  When it is not installed, the built-in
    reader in :mod:`invoicing.att_report` does the same job -- that is what
    makes this skill installable on a machine that has never heard of the
    sibling project.
    """
    try:
        module = load_hours_calculator()
    except HoursSourceUnavailable:
        from . import att_report

        return att_report.load_report(Path(path))
    return module.load_report(Path(path))


def find_workbook(base_dir: Path, explicit: Optional[Path] = None):
    """Locate the time-report workbook (delegates to the sibling module)."""
    try:
        module = load_hours_calculator()
    except HoursSourceUnavailable:
        from . import att_report

        return att_report.find_workbook(Path(base_dir), explicit)
    return module.find_workbook(base_dir, explicit)


def compute(report, contractor_id: str, year: int, month: int):
    """Compute the worked-hours report for one contractor and month."""
    return report.compute(contractor_id, year, month)


def report_from_rows(rows, source=None):
    """Rebuild a ``TimeReportData`` from rows already in the database.

    The reconciliation engine reads the normalised records rather than the
    Excel file, but the audit checks are the ones the review dashboard
    applies -- so the rows are handed back to the sibling module when it is
    installed, and to the built-in reader when it is not.
    """
    try:
        module = load_hours_calculator()
    except HoursSourceUnavailable:
        from . import att_report

        return att_report.TimeReportData(
            [att_report.entry_from_row(dict(row)) for row in rows],
            source=source,
        )
    day_entry = module.DayEntry
    entries = []
    for row in rows:
        entries.append(
            day_entry(
                year=row["period_year"],
                month=row["period_month"],
                period_week=row["period_week"] or "",
                day=_row_int(row["work_date"]),
                week_start=_row_date(row["week_start"]),
                week_end=_row_date(row["week_end"]),
                contractor_attuid=row["contractor_id"],
                first_name=row["first_name"] or "",
                last_name=row["last_name"] or "",
                supervisor_attuid=row["supervisor_attuid"] or "",
                vendor_name=row["vendor_name"] or "",
                segment_name=row["segment_name"] or "",
                correcting_hours=row["correcting_flag"] or "N",
                regular_hours=row["regular_hours"] or 0.0,
                ot_hours=row["ot_hours"] or 0.0,
                week_regular_hours=row["week_regular_hours"],
                week_ot_hours=row["week_ot_hours"],
            )
        )
    return module.TimeReportData(entries, source=source)


def _row_date(value):
    import datetime as dt

    if not value:
        return None
    try:
        return dt.date.fromisoformat(value)
    except ValueError:
        return None


def _row_int(value):
    import datetime as dt

    if not value:
        return 0
    try:
        return dt.date.fromisoformat(value).day
    except ValueError:
        return 0
