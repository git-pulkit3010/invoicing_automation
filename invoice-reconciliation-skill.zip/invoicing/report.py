"""Rendering of a reconciliation result as JSON and as a readable report.

The JSON is the machine contract between the engine and the agent.  The
Markdown is what a reviewer reads.  Both are produced from the same result
object, so they can never disagree.
"""

from __future__ import annotations

import datetime as dt
import json
from decimal import Decimal
from pathlib import Path
from typing import Any, Dict, List, Optional

from .models import (
    STATUS_MATCH,
    STATUS_MISMATCH,
    STATUS_REVIEW,
    InvoiceExtraction,
    ReconciliationResult,
)


def _default(value: Any):
    if isinstance(value, Decimal):
        return str(value)
    if isinstance(value, (dt.date, dt.datetime)):
        return value.isoformat()
    raise TypeError(f"Cannot serialise {type(value)!r}")


def result_to_dict(result: ReconciliationResult) -> Dict:
    """The JSON contract handed to the agent."""
    return json.loads(result.model_dump_json())


def result_to_json(result: ReconciliationResult) -> str:
    return json.dumps(result_to_dict(result), indent=2, default=_default)


def render_brief(result: ReconciliationResult) -> Dict:
    """The compact, agent-facing summary of one reconciliation.

    This is the answer to "what happened with this invoice".  It is small on
    purpose: the agent should be able to read the whole verdict in one go
    and only open the full JSON or the source document when a field needs
    checking.
    """
    return {
        "status": result.status,
        "invoice_file": result.invoice_file,
        "invoice_number": result.invoice_number,
        "vendor_name": result.vendor_name,
        "contractor_id": result.contractor_id,
        "contractor_name": result.contractor_name,
        "period": result.period_label,
        "hours": {
            "timesheet": result.expected_hours,
            "invoice": result.invoice_hours,
            "difference": result.hours_difference,
        },
        "rate": {
            "work_order": result.expected_rate,
            "invoice": result.invoice_rate,
            "difference": result.rate_difference,
        },
        "amount": {
            "expected": result.expected_amount,
            "invoice": result.invoice_amount,
            "difference": result.difference,
        },
        "currency": result.currency,
        "reasons": result.reasons,
        "warnings": result.warnings,
    }


def _money(value) -> str:
    if value is None:
        return "n/a"
    return f"{float(value):,.2f}"


def _hours(value) -> str:
    if value is None:
        return "n/a"
    number = float(value)
    if abs(number - round(number)) < 0.001:
        return str(int(round(number)))
    return f"{number:.2f}"


def _signed(value) -> str:
    if value is None:
        return "n/a"
    number = float(value)
    return f"{number:+,.2f}"


_STATUS_HEADLINE = {
    STATUS_MATCH: "MATCH",
    STATUS_MISMATCH: "MISMATCH",
    STATUS_REVIEW: "REVIEW REQUIRED",
}


def render_markdown(result: ReconciliationResult) -> str:
    """Render the human-readable reconciliation report."""
    lines: List[str] = []
    lines.append("# Invoice reconciliation")
    lines.append("")
    title = " — ".join(
        part for part in (result.contractor_name, result.period_label) if part
    )
    lines.append(f"**{title or result.invoice_file}**")
    lines.append("")
    lines.append(f"- Invoice file: `{result.invoice_file}`")
    if result.invoice_number:
        lines.append(f"- Invoice number: `{result.invoice_number}`")
    if result.vendor_name:
        lines.append(f"- Vendor: {result.vendor_name}")
    if result.contractor_id:
        lines.append(f"- Contractor id: `{result.contractor_id}`")
    lines.append(f"- Status: **{_STATUS_HEADLINE.get(result.status, result.status)}**")
    lines.append("")

    lines.append("## Amounts")
    lines.append("")
    lines.append("| Item | Value |")
    lines.append("| --- | --- |")
    lines.append(f"| Verified billable hours | {_hours(result.expected_hours)} |")
    lines.append(f"| Hours on the invoice | {_hours(result.invoice_hours)} |")
    lines.append(f"| Contracted hourly rate | {_money(result.expected_rate)} |")
    lines.append(f"| Rate on the invoice | {_money(result.invoice_rate)} |")
    lines.append(f"| Expected amount | {_money(result.expected_amount)} |")
    lines.append(f"| Invoice amount | {_money(result.invoice_amount)} |")
    lines.append(f"| Difference | {_signed(result.difference)} |")
    lines.append(f"| Currency | {result.currency} |")
    lines.append("")

    lines.append("## Findings")
    lines.append("")
    for reason in result.reasons:
        lines.append(f"- {reason}")
    if not result.reasons:
        lines.append("- No findings.")
    lines.append("")

    if result.warnings:
        lines.append("## Warnings")
        lines.append("")
        for warning in result.warnings:
            lines.append(f"- {warning}")
        lines.append("")

    audit = result.audit or {}
    work_order = audit.get("work_order")
    if work_order:
        lines.append("## Work order")
        lines.append("")
        lines.append("| Item | Value |")
        lines.append("| --- | --- |")
        lines.append(f"| File | `{work_order.get('source_file')}` |")
        lines.append(f"| Reference | {work_order.get('work_order_ref') or 'n/a'} |")
        lines.append(f"| Vendor | {work_order.get('vendor_name') or 'n/a'} |")
        lines.append(f"| Consultant | {work_order.get('consultant_name') or 'n/a'} |")
        lines.append(f"| Billing rate | {work_order.get('billing_rate') or 'n/a'} |")
        lines.append(f"| Rate unit | {work_order.get('rate_unit') or 'n/a'} |")
        lines.append(f"| Effective from | {work_order.get('start_date') or 'n/a'} |")
        lines.append(f"| Effective to | {work_order.get('end_date') or 'n/a'} |")
        lines.append(
            f"| Covers the billing period | "
            f"{'yes' if work_order.get('covers_period') else 'no'} |"
        )
        lines.append("")

    timesheet = audit.get("timesheet")
    if timesheet:
        summary = timesheet.get("summary", {})
        lines.append("## Timesheet")
        lines.append("")
        lines.append("| Item | Value |")
        lines.append("| --- | --- |")
        lines.append(f"| Rows used | {len(timesheet.get('source_rows', []))} |")
        lines.append(f"| Total hours | {summary.get('total_hours')} |")
        lines.append(f"| Regular hours | {summary.get('regular_hours')} |")
        lines.append(f"| Overtime hours | {summary.get('ot_hours')} |")
        lines.append(f"| Days recorded | {summary.get('days_recorded')} |")
        lines.append(
            f"| Full-month benchmark | {summary.get('benchmark_hours')} |"
        )
        lines.append("")
        for note in timesheet.get("audits", []):
            lines.append(f"- {note.get('check')}: {note.get('finding')}")
        lines.append("")

    lines.append("---")
    lines.append("")
    lines.append(
        f"Generated {result.created_at.isoformat(timespec='seconds')} by the "
        "invoice-reconciliation engine."
    )
    lines.append("")
    return "\n".join(lines)


def write_result(
    result: ReconciliationResult,
    extraction: InvoiceExtraction,
    output_dir: Path,
    source_markdown: Optional[str] = None,
) -> Dict[str, Path]:
    """Write every artefact for one invoice.

    * <stem>.json -- the full result and extraction (the audit trail)
    * <stem>.md   -- the report a reviewer reads
    * <stem>.brief.json -- the compact verdict the agent reads first
    * <stem>.source.md -- the document as Markdown, for spot checks
    """
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    stem = Path(result.invoice_file).stem

    json_path = output_dir / f"{stem}.json"
    md_path = output_dir / f"{stem}.md"
    brief_path = output_dir / f"{stem}.brief.json"
    source_path = output_dir / f"{stem}.source.md"

    payload = result_to_dict(result)
    payload["extraction"] = json.loads(extraction.model_dump_json())
    json_path.write_text(
        json.dumps(payload, indent=2, default=_default), encoding="utf-8"
    )
    md_path.write_text(render_markdown(result), encoding="utf-8")
    brief_path.write_text(
        json.dumps(render_brief(result), indent=2, default=_default),
        encoding="utf-8",
    )
    written = {"json": json_path, "markdown": md_path, "brief": brief_path}
    if source_markdown is not None:
        source_path.write_text(source_markdown, encoding="utf-8")
        written["source_markdown"] = source_path
    return written
