#!/usr/bin/env python3
"""Refresh the normalised reference records (Excel + work orders).

Run this when the master Excel or a work order changes -- not on every
invoice.  The output is JSON so the agent can confirm what was loaded.

    python scripts/ingest_references.py
"""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from invoicing.cli import main  # noqa: E402

if __name__ == "__main__":
    raise SystemExit(main(["ingest-references", *sys.argv[1:]]))
